'use strict';
/*
 *  Definition for the majority of interactions across the Coach Journey application, including the API calls that
 *  retrieve user and CLO data. This definition requires the following libraries to fully function:
 *
 *  1) jQuery - tested on v2.2.3
 *  2) Twitter Bootstrap - tested on v3.3.6
 *  3) Handlebars, runtime version - tested on v4.0.5
 */
var quiz = {};
var monthly_focus = {};
var g2 = {};
monthly_focus.child = false;
monthly_focus.class_link = false;
var globalDataInteractionObj = {
    /*
     *  The objectProperties declaration is meant to serve as a a configuration object for the rest of the script.
     *  Add/change as needed.
     */
    isMapLoaded: false,
    objectProperties: {
        //force an index.php into the ajax template paths. Pull this out for production.
        forcePath:false,
        //properties defined by the platform
		isIPad: (navigator.userAgent.match(/iPad/i) != null),
        appRoot: site_url,
        apiRequestParam: exp_actions.elan_api_request,
        apiUserId: member_profile_data.elan_user_id,
        //if more handlebars templates are to be used, include the mappings here. The 'setTemplates' method in the
        //'handlebarsUtils' object reads this property.
        //mapping structure(key:value) - key = handlebars template id, value = view element class where template is rendered
        handlebarsDomMap: {
            'course-detail-overlay': 'course-detail',
            'course-data-summary-template': 'course-data-container',
            'map-info-template': 'map-info-container',
            'quiz-modal': 'quiz-container'
        },
        //this value will be overwritten, in theory, when all of the ajax content is loaded.
        ajaxContentHeightValue: 0,
        //catching and storing the viewport height into a variable for the opaque page overlay
        viewportHeight: document.documentElement.clientHeight,
        //this array will contain any element classes that should initialize the page level overlay.
        pageToggleElements: [ 'journey-main-menu', 'translator-icon', 'slider-top', 'slider-map' ],
        //capture the ajax responses and store in an object property here
        rawAjaxUserData: null,
        rawAjaxCourseData: null,
        rawAjaxCourseDetailData: null
    },
    /*  End configurations  */
    //container for utility methods that can be used across the definition (UI definitions)
    utilities: {
        //This may need to be revisited as native PHP methods handle date display as well.
        getCurrentMonth: function()  {
            var currentMonthAsString;
            //TODO: clear the input parameter from the date before production deployment
            var localDate = new Date(),
                currentMonth = localDate.getMonth() + 1,
                //this may need to be dynamically appended for region/language
                monthArray = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            for (var index in monthArray)  { if(currentMonth == index)  currentMonthAsString = monthArray[index]; }
                currentMonthAsString = "September";
            $('.current-month').text(currentMonthAsString);
        },
        //helper method to create a computational object to handle the calculations for circle circumferences and partials
        setProgressionCircleParameters: function(jqElemIn)  {
            var circleObj = {};
            circleObj.elemRadius = parseInt(jqElemIn.attr('r'));
            circleObj.elemCircumference = Math.round(2*(Math.PI)*circleObj.elemRadius);
            circleObj.elemRatio = circleObj.elemCircumference / 100;
            return circleObj;
        },
		escapeXml: function(string) {
			return string.replace(/[<>]/g, function (c) {
			  switch (c) {
				case '<': return '\u003c';
				case '>': return '\u003e';
			  }
			});
		},
		findIndexByProperty: function(records, propertyName, propertyValue) {
			return records.findIndex(function(element) { return element[propertyName] == propertyValue; });
		},
		findOneByProperty: function(records, propertyName, propertyValue, recordType) {
			if(records.length > 0) {
				if( typeof(recordType) != 'undefined' && recordType == 'AREA' ) {
					return records.filter(function(element) { return element[propertyName] == propertyValue && element['parent_id'] == 0; })[0]||null;
				} else if( typeof(recordType) != 'undefined' && recordType == 'NEIGHBORHOOD' ) {
					return records.filter(function(element) { return element[propertyName] == propertyValue && element['parent_id'] != 0; })[0]||null;
				} else {
					return records.filter(function(element) { return element[propertyName] == propertyValue; })[0]||null;
				}
			} else {
				return null;
			}
		},
		findAllByProperty: function(records, propertyName, propertyValue) {
			return records.filter(function(element) { return element[propertyName] == propertyValue; })||null;
		},
		sortByProperty: function(records, propertyName) {
			return records.sort(function(a, b) { return a[propertyName] > b[propertyName]; })||null;
		},
		findMapArea: function(records, areaName) {
			areaName = areaName + ' Area'; //Make sure all tags related to area includes 'Area' word at the end in Elan TTN
			return records.filter(function(r) { return (r['OBJECT_TYPE_ID'] == elanObjects.success_track.id || r['OBJECT_TYPE_ID'] == elanObjects.curriculum.id) && r['TAGS'].indexOf(areaName) != -1; })[0]||null;
		},
		findMapNeighborhood: function(records, neighborhoodTagName) {
			return records.filter(function(r) { var tags = $.map(r['TAGS'].split(','), $.trim); return r['OBJECT_TYPE_ID'] == elanObjects.scorm.id && tags.indexOf(neighborhoodTagName) != -1; })[0]||null;
		},
		findMapNeighborhoodAssessment: function(records, neighborhoodTagName) {
			return records.filter(function(r) { var tags = $.map(r['TAGS'].split(','), $.trim); return r['OBJECT_TYPE_ID'] == elanObjects.class.id && tags.indexOf(neighborhoodTagName) != -1; })[0]||null;
		},
		launchNeighborhoodCourse: function(learningObjectId) {
			var learningObject = {};
			if( typeof(learningObjectId) == 'undefined' || learningObjectId == null ) {	
				learningObject = globalDataInteractionObj.mapInteractionHandler.currentMapObject;
			} else {
				learningObject = globalDataInteractionObj.utilities.findOneByProperty(globalDataInteractionObj.mapInteractionHandler.mapLearningObjects, 'OBJECT_ID', learningObjectId);
			}
			//console.log(learningObject);
			
			var handleUserObjectRecord = function(userObjectRecord) {
				//console.log(userObjectRecord);
				if( userObjectRecord ) {						
					//console.log('launchNeighborhoodCourse');						
					var parameters = {};		
					parameters = {
						"type": "launchscorm",
						"object_id": learningObject.OBJECT_ID,
						"record_id": userObjectRecord.RECORD_ID
					};			
					$.ajax(globalDataInteractionObj.ajaxUtilities.ajaxSwitch('GET', parameters, 'api')).done(function(response)  {
						//console.log(response);
						if(response.hasOwnProperty("DATA")) {
							//console.log('launchNeighborhoodCourse');
							var poptions = 'scrollbars=0,directories=0,location=0,menubar=0,toolbar=0,status=0,width=1024,height=768';
							if( coursePopup && !coursePopup.closed ) {							
								coursePopup.focus();
							} else {
								coursePopup = window.open(response.DATA.LAUNCH_URL, 'coursePopup', poptions);
								if( !coursePopup ) {
									alert("We launched your course in a new window but if you do not see it, a popup blocker may be preventing it from opening. Please disable popup blockers for this site.");
								} else {
									// When course pop-up is closed return to map page
									$(coursePopup).on('unload', globalDataInteractionObj.utilities.scormUnload);
								}
							}
						}
					});						
				} else {						
					//console.log(learningObject);
					globalDataInteractionObj.userData.createUserObjectRecord(learningObject, handleUserObjectRecord);
				}
			}
			
			if( typeof(learningObject.OBJECT_ID) != 'undefined' || learningObject.OBJECT_ID != null ) {
				globalDataInteractionObj.userData.fetchUserObjectRecord(learningObject.OBJECT_ID, handleUserObjectRecord);
			}
		},
		scormUnload: function() {
			//console.log('scormUnload');			
			// Onunload is called multiple times in the SCORM window - we only want to handle when it is actually closed.
			var watchPopupClose = setInterval(function() {
				if (coursePopup.closed) {
					//console.log('scormUnload - actually closed');
					clearInterval(watchPopupClose);
					$('a#mapCallToAction').css("pointer-events", "auto");
					globalDataInteractionObj.userData.update();				
				}
			}, 500);
		}
    },
    /*  This is going to be the handler for the ajax data calls across most of the definition.  */
    ajaxUtilities: {
		loading: function(element) {
			// $( element ).html('<p class="text-center"><img src="' + site_url + 'images/ajaxloader.gif"></p>');
		},
	
        //ajax switch between API calls and local json
        ajaxSwitch: function(requestType, params, callSource, localCallSource)  {
			globalDataInteractionObj.userData.checkCookie();
            localCallSource = localCallSource || null;
            //TODO: Remove from production on launch. Shouldn't need to determine retail & outlet users at the client
            if (localCallSource == 'usercoursedata')  {
                localCallSource = globalDataInteractionObj.userData.isRetailOrOutlet() + '/' + localCallSource;
                params = {type: 'getmonthlyfocus'}
            } else if (localCallSource == 'userdata') {
                params = {type: 'userinfowithattr'};
            } else if (localCallSource == 'coursedetaildata') {
                //params = {type: 'coursedetaildata'};                
            }
            var propInstance = globalDataInteractionObj.objectProperties,
                objOut = {};
            objOut.type = requestType;
            objOut.dataType = 'json';
            switch(callSource)  {
                case 'api':
                    objOut.url = propInstance.appRoot;
                    objOut.data = {
                        'ACT': propInstance.apiRequestParam                        
                    };
                    $.each(params, function(key, value)  {
                        objOut['data'][key] = encodeURIComponent(value);
                    });
					if( typeof(objOut['data']['user_id']) == 'undefined' ) {
						objOut['data']['user_id'] = propInstance.apiUserId;
					}
                break;
                //TODO: refactor as API is workable beyond user data. Localized data should not be a default case
                default:
                    objOut.url = 'js/test-data/' + localCallSource + '.json';
            }
            return objOut;
        },
        //this is simply a helper method to concentrate and simplify the known data calls within the definition. Other
        //methods can still use their own ajax requests.
        //This has been added onto a lot so many of the variables do not necessarily make sense in the switch case
        ajaxLauncher: function(typeIn, courseId, parentId, questionId, stepNum)  {
            courseId = courseId || null;
            var callParams = {};
            callParams.httpRequestType = 'GET';
            callParams.dataPoints = null;
            callParams.dataSource = 'api';
            callParams.dataResponse = null;
            callParams.detailId = courseId;
            //selector and sequence runner for the async data calls
            switch(typeIn)  {
                case 'userdata':
                    callParams.sequenceRunner = function(dataIn)  {
                        globalDataInteractionObj.objectProperties.rawAjaxUserData = dataIn;
                        globalDataInteractionObj.ajaxUtilities.runUserAjaxSequence();
                    };
                break;
                case 'usercoursedata':
                    callParams.sequenceRunner = function(dataIn)  {
                        globalDataInteractionObj.objectProperties.rawAjaxCourseData = dataIn;
                        globalDataInteractionObj.ajaxUtilities.runCourseAjaxSequence();
                    };
                break;
                case 'coursedetaildata':
                    callParams.sequenceRunner = function(dataIn, courseId)  {
                        //console.log(courseId);
                        globalDataInteractionObj.objectProperties.rawAjaxCourseDetailData = dataIn;
                        //globalDataInteractionObj.ajaxUtilities.runCourseDetailAjaxSequence(courseId);
                    };
                    callParams.dataPoints = {type: 'coursedetaildata', object_id: courseId, children: parentId};
                break;
                case 'coursedetaillink':
                    callParams.dataPoints = {type: 'coursedetaillink', object_id: courseId, parent_object_id: parentId};
                break;
                case 'updateuserobjectrecord':
                    callParams.dataPoints = {type: 'updateuserobjectrecord', record_id: courseId, status: parentId, score: questionId};
                break;
                case 'getquizquestions':
                    callParams.dataPoints = {type: 'getquizquestions', object_id: courseId, parent_object_id: parentId}
                break;
                case 'submitquizanswers': 
                    callParams.dataPoints = {type: 'submitquizanswers', record_id: courseId, user_ans_no: parentId, question_id: questionId};
                break;
                case 'getcoursevideo': 
                    callParams.dataPoints = {type: 'getcoursevideo', record_id: courseId, step_num: stepNum, object_id: questionId, parent_object_id: parentId};
                break;
                case 'updatecreateuserrecord':
                    callParams.dataPoints = {type: 'updatecreateuserrecord', object_id: courseId, parent_object_id: parentId, status: questionId}
                    if(questionId = 'Complete') {
                        globalDataInteractionObj.ajaxUtilities.removeDisableClassForNextChild(courseId, parentId);
                    }
                break;
            }
            $.ajax(globalDataInteractionObj.ajaxUtilities.ajaxSwitch(callParams.httpRequestType, callParams.dataPoints, callParams.dataSource, typeIn)).done(function(data) {
                callParams.dataResponse = data;
                if(typeIn == 'coursedetaildata') {
                    globalDataInteractionObj.ajaxUtilities.fillCourseDetailModal(data, courseId);
                } else if (typeIn == 'coursedetaillink') {
                    globalDataInteractionObj.ajaxUtilities.runCourseDetailLinkAjaxSequence(data, courseId);
                } else if(typeIn == 'getquizquestions')  {
                    globalDataInteractionObj.handlebarsUtils.setTemplates('quiz-modal', data);
                    quiz.data = data;
                    $('div.pre-load-modal').hide();
                } else if(typeIn == 'getcoursevideo') {
                    var videoModal = $('#video-modal');
                    
                    var video_url = '';
                    var video_bitrate = 0;
                    data.DATA.MEDIA_INFO.encodings.forEach(function(encoding){
                        if(encoding.width == 640 && encoding.container_type == 'Mpegts' && encoding.video_bitrate > video_bitrate) {
                            video_url =encoding.master_playlist_url;
                            video_bitrate = encoding.video_bitrate;
                        }
                    });

                    video_url = video_url.replace(/^http:\/\//i, 'https://');

                    $('#video-modal div.inner').html('<i class="icon-close-btn"></i><video id="video-coach" width="960" height="540" class="video-js vjs-default-skin" controls><source src="" type="application/x-mpegURL" id="video-source"></source></video>');
                    $('#video-source').attr('src',video_url);

                    var player = videojs('#video-coach', {"autoplay": true});
                    $('div.pre-load-modal').fadeOut(300);
                    //player = videoModal.find('video')[0];
                    //toggleMenu('close', .01);
                    TweenLite.to(videoModal, .35, {autoAlpha: 1, ease: 'Power3.easeIn'});
					
                    monthly_focus.child = true;
                    player.load();
                    player.ready(function() {
                        player.play();    
                    });
                    globalDataInteractionObj.ajaxUtilities.ajaxLauncher('updatecreateuserrecord', questionId, parentId,'Complete');
                    $("#"+questionId).parents("li").next().children().children().removeClass('disabled');
                    

                    player.on('ended', function() {
                        //globalDataInteractionObj.ajaxUtilities.updateObjectRecord(courseId, 'Complete', questionId);
                        
                        TweenLite.to(videoModal, .35, {autoAlpha: 0, ease: 'Power3.easeOut'});
                        player.dispose();
                        monthly_focus.child = false;
                      });
                    //body.addClass('no-scroll');

                    $(document).on('click touchstart', '#video-modal', function(e){
                        var clicked = $(e.target);
                        // console.log(clicked);
                        if(clicked.is('#video-modal') || clicked.is('.icon-close-btn')) {
                            if ($('#video-coach').is("div")) {
                                // Destroys the video player and does any necessary cleanup
                                var player = videojs("#video-coach");
                                if (player) {
                                    player.dispose();
                                    //$("div#video-modal #video-coach").empty();
                                }
                            }
                            monthly_focus.child = false;
                            TweenLite.to(videoModal, .35, {autoAlpha: 0, ease: 'Power3.easeOut'});
                            return false;
                        }                         
                    });
                } else if (typeIn == 'userdata') {
                    globalDataInteractionObj.objectProperties.userObjectRecords = data.OBJECT_RECORDS;
                }             
           
               // console.log(data);
            }).fail(function(jqxhr, status)  {
                //console.log(jqxhr + ' status: ' + status);
                callParams.dataResponse = { 'data':'none' };
            }).always(function()  {
				if( typeof(callParams.sequenceRunner) == 'function') {
					callParams.sequenceRunner(callParams.dataResponse, callParams.detailId);
				}
            });
        },
        /*
         *  These are the various initialization methods for the user, course, and course detail, that fetch the various
         *  API responses and render them into their respective views.
         */
        runUserAjaxSequence: function()  {
            var userDataObj = globalDataInteractionObj.userData,
                userDataResponse = globalDataInteractionObj.objectProperties.rawAjaxUserData,
                completionPercentage = globalDataInteractionObj.userData.calculateCourseCompletionPercentage(userDataResponse.DATA.CUSTOM_ATTRIBUTES.COURSES_COMPLETED, userDataResponse.DATA.CUSTOM_ATTRIBUTES.TOTAL_COURSES),
				completionAverage = globalDataInteractionObj.userData.calculateCourseCompletionAverage(userDataResponse.DATA.CUSTOM_ATTRIBUTES.COURSES_COMPLETED, userDataResponse.DATA.CUSTOM_ATTRIBUTES.TOTAL_SCORES);
                userDataObj.displayNameAndTitle(userDataResponse.DATA.FIRST_NAME, userDataResponse.DATA.LAST_NAME, userDataResponse.DATA.CUSTOM_ATTRIBUTES.ML_RANK, userDataResponse.DATA.CUSTOM_ATTRIBUTES.ML_RANK_SINCE);
			userDataObj.displayCityStateCountry(userDataResponse.DATA.LocationCity, userDataResponse.DATA.LocationState, userDataResponse.DATA.LocationCountry);
            userDataObj.displayAssociateRole(userDataResponse.DATA.Role);
            userDataObj.displayJoinCoach(userDataResponse.DATA['Last Hire Date']);
            userDataObj.displayAssociateDate(userDataResponse.DATA.DateInJob);
			userDataObj.displayAssociateAvatar(userDataResponse.DATA.USER_AVATAR);
            userDataObj.displaySliderAvatar(userDataResponse.DATA.USER_AVATAR);
			userDataObj.displayCourseCompletionPercentage(completionPercentage);
            userDataObj.calculateAndDisplayRadialProgressBar(completionPercentage, 'progress-monthly-completion-circle');
			userDataObj.displayCourseCompletionAverage(completionAverage, userDataResponse.DATA.CUSTOM_ATTRIBUTES.COURSES_COMPLETED, userDataResponse.DATA.CUSTOM_ATTRIBUTES.TOTAL_SCORES);
			userDataObj.displayMeterCompletions(userDataResponse.DATA.CUSTOM_ATTRIBUTES.COURSES_COMPLETED);
            userDataObj.calculateAndDisplayRadialProgressBar(completionAverage, 'progress-monthly-average-circle');
            userDataObj.calculateAndDisplayRadialProgressBar(completionPercentage, 'progress-profile-monthly-completion-circle');
			userDataObj.displayQuizAverage();
        },
        runCourseAjaxSequence: function()  {
            var userCourseDataResponse = globalDataInteractionObj.objectProperties.rawAjaxCourseData;
            globalDataInteractionObj.handlebarsUtils.setTemplates('course-data-summary-template', userCourseDataResponse);
            globalDataInteractionObj.courseData.carouselSequence();
            globalDataInteractionObj.courseDetail.eventInit();
        },
        runCourseDetailAjaxSequence: function(courseElem)  {
            var courseDetailData = globalDataInteractionObj.objectProperties.rawAjaxCourseDetailData;
            var mappedData = globalDataInteractionObj.courseDetail.getDetailContentById(courseDetailData.courseDetail, courseElem);
            //console.log(mappedData);
            globalDataInteractionObj.handlebarsUtils.setTemplates('course-detail-overlay', mappedData);
            globalDataInteractionObj.courseDetail.getMatchingCourseAttributes(courseElem);
              globalDataInteractionObj.courseDetail.setUpOverlay('.course-detail');
            $('.close-overlay').on('click touchstart', function()  { globalDataInteractionObj.courseDetail.prepOverlayTeardown('.course-detail'); });
        },
        updateObjectRecord: function(recordId, status, currentLink) {
            //Update the user object record.
            globalDataInteractionObj.ajaxUtilities.ajaxLauncher('updateuserobjectrecord', recordId, status);
            // remove the disabled class to the next sibling
            //console.log(currentLink);
            $("#"+currentLink).parents("li").next().children().children().removeClass('disabled');
        },
        removeDisableClassForNextChild: function(elementId, parentId) {
            $('#'+elementId).parents('li').find('img').attr('src', '/images/checkboxes/check-mark-green.png');
            if($('#'+elementId).parents('li').next().length > 0) {
                $('#'+elementId).parents("li").next().children().children().removeClass('disabled');
            } else {
                $('#'+parentId).addClass('open');
                $('#'+parentId).parent('div').prev().prev().prev().children('img').addClass('open');
            }
            loop1:
                for(var row_key in globalDataInteractionObj.objectProperties.rawAjaxCourseData){
                    // console.log(globalDataInteractionObj.objectProperties.rawAjaxCourseData[key]);
                    for(var object_key in globalDataInteractionObj.objectProperties.rawAjaxCourseData[row_key]) {
                        for(var child_key in globalDataInteractionObj.objectProperties.rawAjaxCourseData[row_key][object_key]['children']) {
                            if(globalDataInteractionObj.objectProperties.rawAjaxCourseData[row_key][object_key]['children'][child_key]['object_id'] == elementId){
                                globalDataInteractionObj.objectProperties.rawAjaxCourseData[row_key][object_key]['children'][child_key]['is_objective_complete'] = true;
                                break loop1;
                            }
                        }
                    }
                }

        },
        runCourseDetailLinkAjaxSequence: function(data) {

        },
        fillCourseDetailModal: function(data, courseElem) {
            data.courseSummary = $('.course-description-'+courseElem).text();            
            globalDataInteractionObj.handlebarsUtils.setTemplates('course-detail-overlay', data);
            $('div.pre-load-modal').hide();            
            globalDataInteractionObj.courseDetail.getMatchingCourseAttributes(courseElem);
            globalDataInteractionObj.courseDetail.setUpOverlay('.course-detail');
            if(monthly_focus.class_link){
                $(document).on('click touchstart', function(e){
                
                        var clicked = $(e.target);
                        // console.log(clicked);
                        if((clicked.is('.icon-close-btn') || clicked.parents('div.course-detail').length == 0) && !clicked.is('span') && !clicked.is('.class-link') && !monthly_focus.child) {
                            globalDataInteractionObj.courseDetail.prepOverlayTeardown('.course-detail'); 
                        }
                        // console.log('close class-link is visible');
                    
                    // console.log('Close class-link');
                    //return false;
                });
                }
            window.onscroll = function(){
                if(monthly_focus.class_link){
                    if(!monthly_focus.child) {
                        globalDataInteractionObj.courseDetail.prepOverlayTeardown('.course-detail'); 
                    }
                }
            };
            //$('body').on('click', '.objective-link', function()  { globalDataInteractionObj.ajaxUtilities.ajaxLauncher('coursedetaillink', this.id, this.getAttribute('attr-parent')); });

      },
        fillQuizQuestions: function(objectId, parentId) {
            globalDataInteractionObj.ajaxUtilities.ajaxLauncher('getquizquestions', objectId, parentId);  
            // globalDataInteractionObj.courseDetail.setUpOverlay('.quiz-container');             
        },
        //TODO: Pull this function out of a production deployment
        addAjaxPathIndex: function(templateName)  {
            var fullPath;
            (globalDataInteractionObj.objectProperties.forcePath) ? fullPath = site_url + '/index.php/' + templateName : fullPath = site_url + templateName;
            return fullPath;
        }
        /*  End initialization methods  */
    },
    /*  End ajax utilities  */
    //container for the handlebars helper and initialization methods
    handlebarsUtils: {
        setHandlebarsHelpers: function() {
            Handlebars.registerHelper('greaterThanThree', function(lengthIn, options) {
                if (lengthIn > 3) { return options.fn(this); }
            });
            Handlebars.registerHelper('isOpen', function(param, options) {
                if (param == 'false') { return options.fn(this); }
            });
            Handlebars.registerHelper('isComplete', function(param, options)  {
                if (param == 'true')  { return options.fn(this); }
            });
            //this (an other helpers) will most likely need to be refined as the Elan stuff is ready
            Handlebars.registerHelper('isLink', function(param, options)  {
                if(param == 'link' || param == 'true' )  {
                    return options.fn(this);
                } else {
                    return options.inverse(this);
                }
            });
            Handlebars.registerHelper('isInstagram', function(param, options)  {
                if(param == 'instagram' || param == 'true' )  {
                    return options.fn(this);
                } else {
                    return options.inverse(this);
                }
            });
        },
        //defining a single method for the initialization of the handlebars templates
        setTemplates: function(elemIdIn, jsonResponse)  {
            this.setHandlebarsHelpers();
            var jQselector = "#" + elemIdIn;
            var classMap = globalDataInteractionObj.objectProperties.handlebarsDomMap;
            for (var prop in classMap) {								
                var jqTemplateElem = '#' + prop,
                    jqViewElem = '.' + classMap[prop];										
                if (jQselector == jqTemplateElem) {
                    var sourceScript = $(jqTemplateElem).html(),
                        template = Handlebars.compile(sourceScript),
                        compiledTemplate = template(jsonResponse);
                    $(jqViewElem).html(compiledTemplate);
                };
            }
        }
    },
    //container for the user data interactions
    userData: {
        type: 'userdata',
		userLearningObjects: {},
        //TODO: This function should not be necessary for a production launch
        isRetailOrOutlet: function()  {
            var pathToUserCourseFile;
            switch(globalDataInteractionObj.objectProperties.apiUserId)  {
                //case '1':
                case '4':
                    pathToUserCourseFile = 'outlet';
                    break;
                default:
                    pathToUserCourseFile = 'retail';
            }
            return pathToUserCourseFile;
        },
		checkCookie: function() {
			$(document).on('click touchstart', function(e){
				if (globalDataInteractionObj.objectProperties.apiUserId == '') {
					var logoutPath = $("a[href*='ACT=13']").attr('href');
					console.log(logoutPath);
					window.location = logoutPath;
				}	
			})
        },
        displayNameAndTitle: function(firstNameIn, lastNameIn, levelIn, rankSinceIn)  {
            $('.assoc-name').text(firstNameIn + ' ' + lastNameIn);
            $('.assoc-rank-date').text(rankSinceIn);
            if(levelIn != 'ML APPRENTICE'){
            $('.assoc-rank').text('ML TRAINEE');
            }
            else {
            $('.assoc-rank').text(levelIn);
            }    

        },
		displayCityStateCountry: function(cityIn, stateIn, countryIn)  {
            $('.assoc-city').text(cityIn + ', ' + stateIn);
            $('.assoc-country').text(countryIn);
        },
		displayJoinCoach: function(joinDateIn)  {
            $('.joined-coach-date').text(joinDateIn);
        },
        displayAssociateRole: function(associateRoleIn)  {
            $('.associate-role').text(associateRoleIn);
        },
        displayAssociateDate: function(associateDateIn)  {
            $('.associate-date').text(associateDateIn);
        },
        displayAssociateAvatar: function(associateAvatarIn)  {
            $('.profile-main-image-avatar').css({"background-image" : "url(" + associateAvatarIn + ")", "background-repeat" : "no-repeat" , "background-size" : "cover" , "background-position" : "center"});    
            if(associateAvatarIn != ''){
            $('.profile-main-image-avatar').css({"background-image" : "url(" + associateAvatarIn + ")", "background-repeat" : "no-repeat" , "background-size" : "cover" , "background-position" : "center"}); 
            } else {
            $('.profile-main-image-avatar').css({"background-image" : "url(" + globalDataInteractionObj.objectProperties.appRoot + "images/profile-empty-avatar.jpg)", "background-repeat" : "no-repeat" , "background-size" : "cover" , "background-position" : "center"});
            }    
        },
        displaySliderAvatar: function(associateAvatarIn)  {
            $('.nav-avatar').css({"background-image" : "url(" + associateAvatarIn + ")", "background-repeat" : "no-repeat" , "background-size" : "cover" , "background-position" : "center"});    
            if(associateAvatarIn != ''){
            $('.nav-avatar').css({"background-image" : "url(" + associateAvatarIn + ")", "background-repeat" : "no-repeat" , "background-size" : "cover" , "background-position" : "center"}); 
            } else {
            $('.nav-avatar').css({"background-image" : "url(" + globalDataInteractionObj.objectProperties.appRoot + "images/profile-empty-avatar.jpg)", "background-repeat" : "no-repeat" , "background-size" : "cover" , "background-position" : "center"});
            }            
        },
		displayNextDestination: function()  {
			var currentMapInfo = globalDataInteractionObj.mapInteractionHandler.getMapInfo();
			var currentNeighborhood = globalDataInteractionObj.mapInteractionHandler.currentNeighborhood;
			var neighborhoodInfo = globalDataInteractionObj.utilities.findOneByProperty(currentMapInfo, 'cat_name', currentNeighborhood, 'NEIGHBORHOOD');

			//console.log(currentNeighborhood);
			//console.log(neighborhoodInfo.cat_url_title);
            $('.next-destination').text(currentNeighborhood);	
			$('.myprofile-row-3-2').html('<img id="destination-image" src="' + globalDataInteractionObj.objectProperties.appRoot + 'images/destinations/' + neighborhoodInfo.cat_url_title + '.jpg" />')
        },
		displayQuizAverage: function(){
			var averageQuiz = Math.round(globalDataInteractionObj.objectProperties.rawAjaxCourseData['total_assessments']/globalDataInteractionObj.objectProperties.rawAjaxCourseData['passed_assessments']*10);
			$('.data-assessment-average').text(averageQuiz+'%');
				if(averageQuiz >= 85){
				$('.data-assessment-average-color').attr("stroke","rgba(100,196,151,1.0)");
				} else {
				$('.data-assessment-average-color').attr("stroke","rgba(247,79,61,1.0)");
				}
			var completionQuiz = Math.round(globalDataInteractionObj.objectProperties.rawAjaxCourseData['passed_assessments']/globalDataInteractionObj.objectProperties.rawAjaxCourseData['total_assessments']*100);
            $('.data-assessment-completion').text(completionQuiz+'%');
				if(completionQuiz >= 85){
				$('.data-assessment-completion-color').attr("stroke","rgba(100,196,151,1.0)");
				} else {
				$('.data-assessment-completion-color').attr("stroke","rgba(247,79,61,1.0)");
				}
		},
        //calculate the two digit integer to be used for the completion percentage 
        calculateCourseCompletionPercentage: function(completedCourses, totalCourses)  {
            var intOut = Math.round((completedCourses / totalCourses).toFixed(2) * 100);
            return intOut;
        },
        //display the completion percentage into the views
        displayCourseCompletionPercentage: function(intIn)  {
            if(isNaN(intIn)){
            var percentageString = '0&#37;';
            } else {
            var percentageString = intIn + '&#37;';
            }
			$('.data-course-completion').html(percentageString);
            
            if(intIn >= 85){
                $('.data-course-completion-color').attr("stroke","rgba(100,196,151,1.0)");
                $('.progress-profile-monthly-completion-circle').attr("stroke","rgba(100,196,151,1.0)");
                $('.progress-monthly-completion-circle').attr("stroke","rgba(100,196,151,1.0)");
            } else {
                $('.data-course-completion-color').attr("stroke","rgba(247,79,61,1.0)");
                $('.progress-profile-monthly-completion-circle').attr("stroke","rgba(247,79,61,1.0)");
                $('.progress-monthly-completion-circle').attr("stroke","rgba(247,79,61,1.0)")
            }
			
        },
		//calculate the two digit integer to be used for the average percentage
        calculateCourseCompletionAverage: function(completedCourses, totalScores)  {
            var intOut = Math.round((totalScores / completedCourses));
            return intOut;
        },
		//display the Monthly Average Score into the views
        displayCourseCompletionAverage: function(intIn, courseCompletedIn, totalScoresIn)  {
            if(isNaN(intIn)){
            var scoreString = '0&#37;';
            }else{
            var scoreString = intIn + '&#37;';
            }
			var numberCourses = courseCompletedIn;
            var numberScores = totalScoresIn/courseCompletedIn;
            var totalPercent = 100-numberScores;


            $('.data-course-average-score').html(scoreString);
			$('.data-course-completed').css({'width': numberScores + '%'});
            $('.data-course-scores').css({'width': totalPercent + '%'});

			           
            if(intIn >= 85){
                $('.data-course-average-color').attr("stroke","rgba(100,196,151,1.0)");
                $('.progress-monthly-average-circle').attr("stroke","rgba(100,196,151,1.0)");
            } else {
                $('.data-course-average-color').attr("stroke","rgba(247,79,61,1.0)");
                $('.progress-monthly-average-circle').attr("stroke","rgba(247,79,61,1.0)");
            }
			
        },
		displayMeterCompletions: function(courseCompletedIn) {
            var completedCourses = courseCompletedIn;
            $('.gauge').attr('data-value', completedCourses);
            g2.refresh(courseCompletedIn);
        },

        //
        calculateAndDisplayRadialProgressBar: function(intIn, elemIn)  {
            var jqSelector = "." + elemIn,
                circleObjInstance = globalDataInteractionObj.utilities.setProgressionCircleParameters($(jqSelector));
            $(jqSelector).attr('stroke-dasharray', circleObjInstance.elemCircumference);
            //TODO: something to validate that intIn is always be between 0 and 100 (exception handling, unit test outside the global definition)
            var radialProgressInt = Math.round(intIn * circleObjInstance.elemRatio);
            //the animation effect needs to happen after the course completion percentage has been received. Setting an arbitrary time for now.
            setTimeout( function()  {
                $(jqSelector).addClass('animation-trigger');
                $(jqSelector).attr('stroke-dashoffset', radialProgressInt);
            }, 1000);
        },
		//
		displayPassportStamps: function() {
			var areaObjectId = '';
			var areaObjectStatus = '';
			var numberOfStamps = 0;
			var currentMapInfo = globalDataInteractionObj.mapInteractionHandler.getMapInfo();
			var areas = globalDataInteractionObj.utilities.findAllByProperty(currentMapInfo, 'parent_id', '0');
			areas = globalDataInteractionObj.utilities.sortByProperty(areas, 'unlockorder');
			
			$.each( areas, function( akey, avalue ) {
				//console.log(avalue.cat_url_title);
				var areaObject = globalDataInteractionObj.utilities.findMapArea(globalDataInteractionObj.mapInteractionHandler.mapLearningObjects, avalue.cat_name);
				//console.log(areaObject);
				areaObjectStatus = '';
				if(typeof(areaObject) == 'object' && areaObject != null) {
					areaObjectId = areaObject.OBJECT_ID;
					areaObjectStatus = globalDataInteractionObj.userData.getUserObjectRecordStatus(areaObjectId);
					if( areaObjectStatus == 'Complete' ) {
						numberOfStamps++;
					}
				}				
			});
			
			$( ".stamps-amount" ).text(numberOfStamps);			
		},
		//
		displayJourneyAccordion: function() {					
			var accordionBody = $("div#accordion div#mlapprentice div.panel-body");
			$(accordionBody).empty();
			
			var currentMapInfo = globalDataInteractionObj.mapInteractionHandler.getMapInfo();
			var areas = globalDataInteractionObj.utilities.findAllByProperty(currentMapInfo, 'parent_id', '0');
			areas = globalDataInteractionObj.utilities.sortByProperty(areas, 'unlockorder');
			
			$.each( areas, function( akey, avalue ) {				
				var neighborhoods = globalDataInteractionObj.utilities.findAllByProperty(currentMapInfo, 'parent_id', avalue.cat_id);
				neighborhoods = globalDataInteractionObj.utilities.sortByProperty(neighborhoods, 'unlockorder');
				$.each( neighborhoods, function( nkey, nvalue ) {
					var neighborhoodObject = globalDataInteractionObj.utilities.findMapNeighborhood(globalDataInteractionObj.mapInteractionHandler.mapLearningObjects, nvalue.cat_name);
					//console.log(neighborhoodObject);
					var neighborhoodRow = '';
					if(typeof(neighborhoodObject) == 'object' && neighborhoodObject != null) {
						var currentNeighborhoodStatus = globalDataInteractionObj.userData.getUserObjectRecordStatus(neighborhoodObject.OBJECT_ID);
						var currentNeighborhoodScore = globalDataInteractionObj.userData.getUserObjectRecordScore(neighborhoodObject.OBJECT_ID);
						if( currentNeighborhoodStatus == 'Started') {
							neighborhoodRow = '<div class="col-lg-12 col-md-12 panel-row in-progress">';
						} else {
							neighborhoodRow = '<div class="col-lg-12 col-md-12 panel-row">';
						}
						neighborhoodRow += '<div class="col-md-1 itinerary-completed-check ">';
						if( currentNeighborhoodStatus == 'Complete') {
							neighborhoodRow += '<img src="'+globalDataInteractionObj.objectProperties.appRoot+'images/checkboxes/check-mark-green.png" class="image-checkbox-monthly-focus"/>';
						} else {
							neighborhoodRow += '<img src="'+globalDataInteractionObj.objectProperties.appRoot+'images/checkboxes/nocheck-mark.png" class="image-checkbox-monthly-focus"/>';
						}
						neighborhoodRow += '</div>';
						    neighborhoodRow += '<div class="col-md-5 itinerary-course-title"><h3>'+neighborhoodObject.OBJECT_NAME+'</h3><h3><span class="itinerary-course-title-2"> '+avalue.cat_name+'</span></h2></div>';
						if( currentNeighborhoodStatus == 'Complete') {
							neighborhoodRow += '<div class="col-md-3 itinerary-score">';
							/*
							neighborhoodRow += '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 33 100 50">';
							neighborhoodRow += '<circle cx="50" cy="50" r="15" stroke="rgba(100,196,151,1.0)" fill="rgba(100,196,151,1.0)" />';
							neighborhoodRow += '<g><text x="51" y="54" fill="white" text-anchor="middle" class="single-data-course-average-score"> 100% </text></g>';
							neighborhoodRow += '<text x="38" y="78" fill="black" font-size="8">SCORE</text>';
							neighborhoodRow += '</svg>';
							*/
							if(currentNeighborhoodScore >= 85){
							neighborhoodRow += '<div class="panel-circle itinerary-score" style="background-color:rgb(100,196,151);">';
							}
							else
							{
							neighborhoodRow += '<div class="panel-circle itinerary-score" style="background-color:rgb(247,79,61);">';
							}
							neighborhoodRow += '<span class="single-data-course-average-score">' + currentNeighborhoodScore + '%</span>';
							neighborhoodRow += '<h5 class="score-text">SCORE</h5>';
							neighborhoodRow += '</div>';
							neighborhoodRow += '</div>';
							neighborhoodRow += '<div class="col-md-2 itinerary-links"><a class="callToAction" data-objectid="'+neighborhoodObject.OBJECT_ID+'" href="javascript://">REVIEW</a></div>';
							//console.log(currentNeighborhoodScore);
						} else if( currentNeighborhoodStatus == 'Started' ) {
							neighborhoodRow += '<div class="col-md-3 itinerary-score">IN PROGRESS';
							/*
							neighborhoodRow += '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 33 100 50">';
							neighborhoodRow += '<text x="25" y="60" fill="black" font-size="8">IN PROGRESS</text>';
							neighborhoodRow += '</svg>';
							*/
							neighborhoodRow += '</div>';
							neighborhoodRow += '<div class="col-md-2 itinerary-links"><a class="callToAction" data-objectid="'+neighborhoodObject.OBJECT_ID+'" href="javascript://">CONTINUE</a></div>';
						} else {
							neighborhoodRow += '<div class="col-md-3 itinerary-score">';
							/*
							neighborhoodRow += '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 33 100 50"></svg>';
							*/
							neighborhoodRow += '</div>';
							neighborhoodRow += '<div class="col-md-2 itinerary-links"></div>';
						}
						
						neighborhoodRow += '</div>';
					}
					$(accordionBody).append(neighborhoodRow);
				});				
			});
			
			$(accordionBody).find('a.callToAction').click(function() {
				var learningObjectId = $(this).attr("data-objectid");	
				globalDataInteractionObj.utilities.launchNeighborhoodCourse(learningObjectId);
			});
		},
        myProfileTabEventHandler: function()  {
            $('.btn-toggle').on('click touchstart', function()  {
                $('.is-open').removeClass('glyphicon-minus').addClass('glyphicon-plus');
                    var isExpanded = $(this).attr('data-target'),
                    textViewable = $(isExpanded).hasClass('in'),
                    toggleElem = $(this).find('.is-open');
                toggleElem.removeClass('glyphicon-plus, glyphicon-minus');
                textViewable ? toggleElem.addClass('glyphicon-plus') : toggleElem.addClass('glyphicon-minus');
            });
        },
		fetchUserObjectRecords: function(callback) {
			var parameters = {};
	
			parameters = {
				"type": "userobjectrecords"
			};
			
			$.ajax(globalDataInteractionObj.ajaxUtilities.ajaxSwitch('GET', parameters, 'api')).done(function(response)  {
				if(response.hasOwnProperty("DATA")) {
					globalDataInteractionObj.userData.userLearningObjects = response.DATA;
					//console.log(globalDataInteractionObj.userData.userLearningObjects);
					if( typeof(callback) == "function") {
						callback();
					}					
				}				
			});
		},
		fetchUserObjectRecord: function(currentObjectId, callback) {
			var parameters = {};
	
			parameters = {
				"type": "userobjectrecords",
				"object_id": currentObjectId
			};
			
			var userObjectRecord = false;
			$.ajax(globalDataInteractionObj.ajaxUtilities.ajaxSwitch('GET', parameters, 'api')).done(function(response)  {
				//console.log(response);
				if(response.hasOwnProperty("DATA")) {
					userObjectRecord = response.DATA[0];
				}
				if( typeof(callback) == "function") {
					callback(userObjectRecord);
				}
			});
		},
		createUserObjectRecord: function(currentObject, callback) {
			var parameters = {};
	
			parameters = {
				"type": "createuserobjectrecord",
				"object_id": currentObject.OBJECT_ID,
				"status": "Started",
				"parent_object_id": currentObject.OBJECT_PARENT_IDS
			};			
			//console.log(parameters);
			
			var userObjectRecord = false;
			$.ajax(globalDataInteractionObj.ajaxUtilities.ajaxSwitch('GET', parameters, 'api')).done(function(response)  {
				//console.log(response);
				if(response.hasOwnProperty("DATA")) {
					userObjectRecord = response.DATA;
				}
				if( typeof(callback) == "function") {
					callback(userObjectRecord);
				}
			});
			
		},
		updateUserObjectRecord: function(recordId, status, callback) {
			var parameters = {};
	
			parameters = {
				"type": "updateuserobjectrecord",
				"record_id": recordId,
				"status": status
			};
			
			var userObjectRecord = false;
			$.ajax(globalDataInteractionObj.ajaxUtilities.ajaxSwitch('GET', parameters, 'api')).done(function(response)  {
				//console.log(response);
				if(response.hasOwnProperty("DATA")) {
					userObjectRecord = response.DATA;
				}
				if( typeof(callback) == "function") {
					callback(userObjectRecord);
				}
			});
		},
		updateUserObjectRecordStatusByObjectId: function(objectId, status, callback) {			
			if( typeof(objectId) != 'undefined' && objectId != null ) {
				var objectRecord = globalDataInteractionObj.utilities.findOneByProperty(globalDataInteractionObj.userData.userLearningObjects, 'OBJECT_ID', objectId);
				//console.log(recordObject);
				if( typeof(objectRecord) == 'object' && objectRecord != null ) {
					if( objectRecord.hasOwnProperty("RECORD_ID") ) {
						globalDataInteractionObj.userData.updateUserObjectRecord(objectRecord.RECORD_ID, status, callback);
					}
				}
			}
		},
		getUserObjectRecordStatus: function(objectId) {
			var userObjectRecordStatus = 'locked';
			if( typeof(objectId) != 'undefined' && objectId != null ) {
				var objectRecord = globalDataInteractionObj.utilities.findOneByProperty(globalDataInteractionObj.userData.userLearningObjects, 'OBJECT_ID', objectId);
				//console.log(objectRecord);
				if( typeof(objectRecord) == 'object' && objectRecord != null ) {
					if( objectRecord.hasOwnProperty("STATUS") ) {
						userObjectRecordStatus = objectRecord.STATUS;
					}
				}
			}
			return userObjectRecordStatus;
		},
		getUserObjectRecordScore: function(objectId) {
			var userObjectRecordScore = '';
			if( typeof(objectId) != 'undefined' && objectId != null ) {
				var objectRecord = globalDataInteractionObj.utilities.findOneByProperty(globalDataInteractionObj.userData.userLearningObjects, 'OBJECT_ID', objectId);
				//console.log(objectRecord);
				if( typeof(objectRecord) == 'object' && objectRecord != null ) {
					if( objectRecord.hasOwnProperty("SCORE") ) {
						userObjectRecordScore = objectRecord.SCORE;
					}
				}
			}
			return userObjectRecordScore;
		},
		updateProfile: function() {
			globalDataInteractionObj.userData.displayNextDestination();
			globalDataInteractionObj.userData.displayPassportStamps();
			globalDataInteractionObj.userData.displayJourneyAccordion();
		},
		update: function() {
			globalDataInteractionObj.userData.fetchUserObjectRecords(function() {
				//To set pins on map and display neighborhood as per status and unlock order
				globalDataInteractionObj.mapInteractionHandler.currentArea = null;
				globalDataInteractionObj.mapInteractionHandler.currentNeighborhood = null;				
				var nextNeighborhood = globalDataInteractionObj.mapInteractionHandler.getNeighborhoodObjectStatus();				
				var currentArea = globalDataInteractionObj.mapInteractionHandler.currentArea;
				globalDataInteractionObj.mapInteractionHandler.displayAreaData(currentArea);
				globalDataInteractionObj.mapInteractionHandler.displayNeighborhoodData(nextNeighborhood);
				//Highlight current area
				var currentMapInfo = globalDataInteractionObj.mapInteractionHandler.getMapInfo();
				var neighborhoodInfo = globalDataInteractionObj.utilities.findOneByProperty(currentMapInfo, 'cat_name', nextNeighborhood, 'NEIGHBORHOOD');
				globalDataInteractionObj.mapInteractionHandler.doEventChanges('autoHash', neighborhoodInfo.parent_url_title, neighborhoodInfo.parent_name);
				
				//Update data on profile page
				globalDataInteractionObj.userData.updateProfile();
			});
		},
        //version 2 API call - adding fail scenarios
        userInit: function()  {
			globalDataInteractionObj.userData.fetchUserObjectRecords();
            globalDataInteractionObj.ajaxUtilities.ajaxLauncher(this.type);
            this.myProfileTabEventHandler();
        }
    },
    //container for the course data (CLO) interactions. The current design assumes that, upon a successful login, a user's
    //course progress will be sent without a direct dependency to a user's data (i.e. the web browser will not have to
    //depend on passing user data as a parameter for the course data call)
    courseData: {
        type: 'usercoursedata',
        /*
         *  This method is weird. To avoid adding a new plugin to the stack for a carousel, the app will use Twitter
         *  Bootstrap's carousel...but to get three items in one slide, the DOM has to be dynamically appended. For each
         *  element in the carousel with the class, 'item', this method will evaluate the parent (item), get the content
         *  inside the next 'item' elements and append the selected element. CSS controls the display.
         */
        carouselSequence: function()  {
            $('.carousel .item').each(function() {
                var next = $(this).next();
                if (!next.length) { next = $(this).siblings(':first'); }
                next.children(':first-child').clone().appendTo($(this));
                if (next.next().length > 0) { next.next().children(':first-child').clone().appendTo($(this)); }
                else { $(this).siblings(':first').children(':first-child').clone().appendTo($(this)); }
            });
        },
        courseInit: function()  {
            if(document.getElementById('course-data-summary-template')) {
                globalDataInteractionObj.ajaxUtilities.ajaxLauncher(this.type);
            }
        }
    },
    //container for the course detail data interactions, almost always triggered by a click event on the course detail
    //in the view.
    courseDetail: {
        //This is a DOM traversal method used to get matching presentation elements into course detail overlay. Depending
        //on the API call, this method may need to be refactored, or removed entirely if all of the presentation data can
        //come from the services
        type: 'coursedetaildata',
        getMatchingCourseAttributes: function(elemIdIn)  {
            var jQselector = "#" + elemIdIn,
                uiAttrElem = $(jQselector).parent().siblings('.attr-container'),
                selectedImg = uiAttrElem.children('img').attr('src'),
                courseTitleContainer = $(jQselector).parent().siblings('.course-title-container'),
                sectionHeadingContainer = $(jQselector).parent().siblings('.course-type-container'),
                sectionHeadingTitle = sectionHeadingContainer.children('h3').text(),
                courseTitle = courseTitleContainer.children('h4').text();
            $('.course-heading').append('<h3>' + sectionHeadingTitle + '</h3>');
            $('#imgWrapper').append('<img src=' + selectedImg + ' />');
            $('#traversalData').append('<h4>' + courseTitle + '</h4>');
        },
        //This is ugly, but functional, for launch, find a more efficient way to get specific detail data.
        getDetailContentById: function(dataResponse, dataElem)  {
            var dataOut;
            for (var index in dataResponse)  {
                var selector = dataResponse[index].course_id;
                if(dataElem == selector)  {
                    dataOut = dataResponse[index];
                }
            }
            return dataOut;
        },
        setUpOverlay: function(element)  {
            $(element).removeClass('fade-out-trigger').addClass('fade-in-trigger');
        },
        prepOverlayTeardown: function(element)  {
            $(element).addClass('fade-out-trigger').removeClass('fade-in-trigger');
            setTimeout(function()  { $(element).empty(); },750);
            monthly_focus.class_link = false;
        },
        //this init function is driven by a user click event. Each clickable 'Explore' link should display the associated course data.
        eventInit: function()  {
            $('.misc-link').on('click', function() {
                //console.log("click-"+globalDataInteractionObj.courseDetail.type+'-'+this.id);
                globalDataInteractionObj.ajaxUtilities.ajaxLauncher(globalDataInteractionObj.courseDetail.type, this.id);
            });
            $('.class-link').on('click', function() {
                // console.log($(this).attr('attr-link'));
                if ($(this).attr('attr-link') != "") {
                    window.open($(this).attr('attr-link'), '_blank');
                    var object_id = $(this).attr('id');
                    globalDataInteractionObj.ajaxUtilities.ajaxLauncher('updatecreateuserrecord', object_id, '','Complete');
                    $(this).addClass('open');
                } else {
                    var children = $(this).attr('attr-children');
                    var data_location = $(this).attr('attr-location').split('-');
                    var parent_id = $(this).attr('id');
                    $('div.pre-load-modal').fadeIn(300);
                    //console.log(globalDataInteractionObj.objectProperties.rawAjaxCourseData[data_location[0]][data_location[1]]);
                    monthly_focus.location = data_location;
                    monthly_focus.class_link = true;
                    globalDataInteractionObj.ajaxUtilities.fillCourseDetailModal(globalDataInteractionObj.objectProperties.rawAjaxCourseData[data_location[0]][data_location[1]], parent_id);
                }
                
                //console.log('class-link');
                return false;
            });

			$('.misc-nolink').on('click', function() {
				window.open('https://www.instagram.com/coach/', '_blank');
            });
        }
    },
    //container for the event-driven interactions in the global footer and left navigation
    interactionHandler: {
        setHeightForObjectProperty: function(propertyIn, heightIn)  {
            propertyIn = heightIn;
        },        
        //this init should be called after the ajax content has loaded. For now, this main method is wrapped in a setTimeout function
        //TODO: Rewrite with ES6 promises???? (Might want to restructure all of the event handlers if we go this route)
        subInit: function()  {
            var resizer;
            $(window).on('resize', function(e)  {
				
				//Set height for map content		
				globalDataInteractionObj.mapInteractionHandler.setContentHeight();
					
                clearTimeout(resizer);
                resizer = setTimeout(function()  {
                    globalDataInteractionObj.interactionHandler.setHeightForObjectProperty(globalDataInteractionObj.objectProperties.viewportHeight, document.documentElement.clientHeight);

					$(window).scrollTop(0);
					
					//Set height for map content		
					globalDataInteractionObj.mapInteractionHandler.setContentHeight();
					
                }, 250);
            });
        }
    },		
	//container for the event-driven interactions in the journey map
	mapInteractionHandler: {
		mapLearningObjects: {},
		currentJQVMapObject: {},
		currentMapObject: {},
		currentMap: null,
		currentMapObjectId: null,			
		currentArea: null,
		currentAreaObjectId: null,
		currentNeighborhood: null,
		currentNeighborhoodObjectId: null,
		loadSlideOutPanel: function() {
			//console.log('showSlideOutPanel');
			var windowHeight = $(window).height();
			var globalFooterHeight = $( "div.global-footer" ).height() + 20;
			var contentHeight = windowHeight - globalFooterHeight;
			//$( "#main_content" ).css( "height", contentHeight);
			$( "div.journey-content" ).css( "height", contentHeight);				
			
			globalDataInteractionObj.ajaxUtilities.loading('div.journey-content');
			$('div.journey-content').load(globalDataInteractionObj.ajaxUtilities.addAjaxPathIndex('journey'), function() {
				$( "div.map-container" ).css( "height", contentHeight);
				$( "div.map-info-container" ).css( "height", contentHeight);
				$( "div#vmap" ).css( "height", contentHeight);
				globalDataInteractionObj.ajaxUtilities.loading('div.map-info-container');
				globalDataInteractionObj.mapInteractionHandler.mapDataInit();
			});					
		},
		setContentHeight: function() {
			
			var is_iPad = globalDataInteractionObj.objectProperties.isIPad;
			//alert(is_iPad);
			
			//Set width for map content to set pins on proper position
			var journeyContentWidth = $( "div#mapJourney" ).width();
			//alert('journeyContentWidth: ' + journeyContentWidth);
			if( journeyContentWidth > 0) {				
				var mapInfoWidth = $( "div.journey-content div.map-info-container" ).width();
				//alert('mapInfoWidth: ' + mapInfoWidth);
				var mapWidth = journeyContentWidth - mapInfoWidth;				
				if(journeyContentWidth <= 1800) {
					mapWidth = mapWidth + 30;
				}
				if( mapWidth < 759 ) {
					mapWidth = 759;
				}
				//alert('mapWidth: ' + mapWidth);
				$( "div.journey-content div.map-container div#vmap" ).width(mapWidth);				
				$( "div.journey-content div.map-container div#vmap svg" ).width(mapWidth);
			}
			
			//Set height for map content
			var windowHeight = $(window).height();
			//alert('windowHeight:' + windowHeight);
			var globalFooterHeight = $( "footer#main-footer" ).height();
			//alert('globalFooterHeight:' + globalFooterHeight);
			var contentHeight = windowHeight - globalFooterHeight;
			//alert('contentHeight:' + contentHeight);
			//$( "#main_content" ).css( "height", contentHeight);				
			//alert($( "div#mapJourney" ).height());
			//alert($( "div.journey-content" ).height());
			$( "div.journey-content" ).css( "height", contentHeight);
			$( "div.map-container" ).css( "height", contentHeight);
			$( "div.map-info-container" ).css( "height", contentHeight);
			$( "div#vmap" ).css( "height", contentHeight);
			
			//alert($( "div#vmap svg" ).height());
			$( "div#vmap svg" ).height(contentHeight);
			//alert($( "div#vmap svg" ).height());

			var extraHeight = 0; //Padding above image
			
			if( is_iPad ) {
				extraHeight += $( ".map-info-container img.main-image" ).height();
				if( extraHeight <= 0 ) {
					extraHeight = 213;
				}
			} else {
				extraHeight += $( ".map-info-container img.main-image" ).height();
			}
			//console.log('extraHeight:' + extraHeight);
			//alert('extraHeight:' + extraHeight);
			extraHeight += $( "div.map-heading" ).height() + 9;
			//console.log('extraHeight:' + extraHeight);
			//alert('extraHeight:' + extraHeight);
			extraHeight += $( "div.panel-heading" ).height() + 19;
			//console.log('extraHeight:' + extraHeight);
			//alert('extraHeight:' + extraHeight);
			if( $( "div.panel-footer" ).height() != null ) {
				extraHeight += 37;			
			} else {
				extraHeight += 10;
			}
			//console.log('extraHeight:' + extraHeight);
			//alert('extraHeight:' + extraHeight);
			var panelBodyHeight = contentHeight - extraHeight;
			$( "div.panel-body" ).css( "height", panelBodyHeight);
		},		
		getNeighborhoodObjectStatus: function(neighborhoodObjectId) {			
			var currentAreaId = '';
			var currentAreaStatus = '';
			var currentNeighborhoodId = '';
			var currentNeighborhoodStatus = '';
			var currentNeighborhoodTagName = '';
			var previousNeighborhoodStatus = '';
			var previousNeighborhoodTagName = '';
			if( !neighborhoodObjectId || neighborhoodObjectId == "" ) {
				neighborhoodObjectId = 0;
			}
			//console.log('neighborhoodObjectId: ' + neighborhoodObjectId);
			var currentMapInfo = globalDataInteractionObj.mapInteractionHandler.getMapInfo();
			var elanMapUnlockObjectId = globalDataInteractionObj.mapInteractionHandler.getElanMapUnlockObjectId();
	
			var areas = globalDataInteractionObj.utilities.findAllByProperty(currentMapInfo, 'parent_id', '0');
			areas = globalDataInteractionObj.utilities.sortByProperty(areas, 'unlockorder');
			//console.log(areas);
			
			var neighborhoods = [];					
			$.each( areas, function( akey, avalue ) {
				//console.log(avalue.cat_url_title);
				var areaObject = globalDataInteractionObj.utilities.findMapArea(globalDataInteractionObj.mapInteractionHandler.mapLearningObjects, avalue.cat_name);
				//console.log(areaObject);
				if(typeof(areaObject) == 'object' && areaObject != null) {
					currentAreaId = areaObject.OBJECT_ID;
				}
				currentAreaStatus = 'locked';
				if( currentAreaId != '' ) {						
					currentAreaStatus = globalDataInteractionObj.userData.getUserObjectRecordStatus(currentAreaId);
				}
				//console.log('Area: ' + currentAreaId + ' - ' + currentAreaStatus);
				
				neighborhoods = globalDataInteractionObj.utilities.findAllByProperty(currentMapInfo, 'parent_id', avalue.cat_id);
				neighborhoods = globalDataInteractionObj.utilities.sortByProperty(neighborhoods, 'unlockorder');
				//console.log(neighborhoods);
				$.each( neighborhoods, function( nkey, nvalue ) {
					//console.log(nvalue.cat_name);
					var neighborhoodObject = globalDataInteractionObj.utilities.findMapNeighborhood(globalDataInteractionObj.mapInteractionHandler.mapLearningObjects, nvalue.cat_name);
					//console.log(neighborhoodObject);
					if(typeof(neighborhoodObject) == 'object' && neighborhoodObject != null) {
						currentNeighborhoodId = neighborhoodObject.OBJECT_ID;
					}

					currentNeighborhoodTagName = nvalue.cat_name;
					currentNeighborhoodStatus = 'locked';						
					if( currentNeighborhoodId != '' ) {						
						currentNeighborhoodStatus = globalDataInteractionObj.userData.getUserObjectRecordStatus(currentNeighborhoodId);
					}
					
					if( currentNeighborhoodStatus == 'locked' && (previousNeighborhoodStatus == 'Complete' || previousNeighborhoodStatus == 'Passed') ) {						
						currentNeighborhoodStatus = 'open';						
					}					
					
					// By default open first neighborhood					
					if( currentNeighborhoodId == elanMapUnlockObjectId && currentNeighborhoodStatus == 'locked') {
						currentNeighborhoodStatus = 'open';
					}					
					//console.log('Neighborhood: ' + currentNeighborhoodId + ' - ' + currentNeighborhoodStatus);
					
					if( neighborhoodObjectId == 0) {
						var pinType = '';
						if( currentNeighborhoodStatus == 'open' || currentNeighborhoodStatus == 'Started' ) {
							if( currentNeighborhoodStatus == 'Started' ) {
								pinType = 'progress';
							}
							var currentArea = globalDataInteractionObj.mapInteractionHandler.currentArea;
							//console.log('currentArea: ' + currentArea);
							if( typeof(currentArea) == 'undefined' || currentArea == null ) {
								globalDataInteractionObj.mapInteractionHandler.currentArea = avalue.cat_name;
								globalDataInteractionObj.mapInteractionHandler.currentNeighborhood = nvalue.cat_name;
							}
						} else if( currentNeighborhoodStatus == 'Complete' || currentNeighborhoodStatus == 'Passed' ) {
							pinType = 'complete';							
						}
						if( pinType != '') {
							var pinImageName = 'pin-'+pinType+'-' + avalue.cat_url_title + '.png';
							var pingImagePath = globalDataInteractionObj.objectProperties.appRoot+"images/marker/"+pinImageName;
							var pinContent = "<div class='map-pin'><span class='pin-img' ";
							pinContent += "style=\"background-image: url('"+pingImagePath+"')\"";
							pinContent += ">";
							pinContent += "</span></div>";
							globalDataInteractionObj.mapInteractionHandler.setPin(nvalue.cat_url_title, pinContent);
						}
					}
					
					//console.log(previousNeighborhoodTagName);
					if( currentNeighborhoodStatus == 'open' && previousNeighborhoodTagName != '' ) {
						var previousNeighborhoodAssessmentObject = globalDataInteractionObj.utilities.findMapNeighborhoodAssessment(globalDataInteractionObj.mapInteractionHandler.mapLearningObjects, previousNeighborhoodTagName);
						//console.log(previousNeighborhoodAssessmentObject);
						if( typeof(previousNeighborhoodAssessmentObject) != 'undefined' && previousNeighborhoodAssessmentObject != null ) {
							var previousNeighborhoodAssessmentStatus = globalDataInteractionObj.userData.getUserObjectRecordStatus(previousNeighborhoodAssessmentObject.OBJECT_ID);							
							//console.log(previousNeighborhoodTagName + ' -> ' + previousNeighborhoodAssessmentStatus);
							if( previousNeighborhoodAssessmentStatus != 'Complete' ) {
								currentNeighborhoodStatus = 'locked';
							}
						}
					}
					//console.log(previousNeighborhoodStatus + ' -> ' + currentNeighborhoodStatus);
					
					previousNeighborhoodStatus = currentNeighborhoodStatus;					
					previousNeighborhoodTagName = currentNeighborhoodTagName;
					
					// Exit from Neighborhoods loop
					if( currentNeighborhoodId == neighborhoodObjectId ) {								
						return false;
					}
				});
				// Exit from Areas loop
				if( currentNeighborhoodId == neighborhoodObjectId ) {								
					return false;
				}
				
				// Mark area is complete if all neighborhoods are complete
				if( neighborhoodObjectId == 0 && currentAreaId != '' && currentAreaStatus == 'Started' && currentNeighborhoodStatus == 'Complete') {
					globalDataInteractionObj.userData.updateUserObjectRecordStatusByObjectId(currentAreaId, 'Complete');
				}
			});
			
			if( neighborhoodObjectId == 0 ) {				
				globalDataInteractionObj.mapInteractionHandler.displayPins();
				return globalDataInteractionObj.mapInteractionHandler.currentNeighborhood;
			} else {
				return currentNeighborhoodStatus;	
			}
		},
		fetchMapLearningObjects: function(mapTagName) {
			var parameters = {};
			
			if(!mapTagName) {
				mapTagName = globalDataInteractionObj.mapInteractionHandler.currentMap;
			}
			
			parameters = {
				"type": "learninginfo",			
				"tags": mapTagName
			};
			
			//'local', 'multiplelearningobjects'
			$.ajax(globalDataInteractionObj.ajaxUtilities.ajaxSwitch('GET', parameters, 'api')).done(function(response)  {
				if(response.hasOwnProperty("DATA")) {
					globalDataInteractionObj.mapInteractionHandler.mapLearningObjects = response.DATA;
					//console.log(globalDataInteractionObj.mapInteractionHandler.mapLearningObjects);
					globalDataInteractionObj.mapInteractionHandler.preLoadLearningObjectImages();
					globalDataInteractionObj.mapInteractionHandler.displayCurrentData();
				}				
			}).fail(function(jqxhr, status)  {
				console.log(jqxhr + ' status: ' + status);
			});
		},
		preLoadLearningObjectImages: function() {
			var mapLearningObjects = globalDataInteractionObj.mapInteractionHandler.mapLearningObjects;
			$.each( mapLearningObjects, function( key, learningObject) {
				$('<img/>')[0].src = learningObject.OBJECT_IMAGE;
			});				
		},
		setCurrentObject: function(currentLevel, currentObject) {
			currentObject.OBJECT_LEVEL = currentLevel;
			currentObject.OBJECT_PARENT_IDS = "";
			if ( currentLevel == "MAP" ) {
				globalDataInteractionObj.mapInteractionHandler.currentMapObjectId = currentObject.OBJECT_ID;
				globalDataInteractionObj.mapInteractionHandler.currentAreaObjectId = null;
				globalDataInteractionObj.mapInteractionHandler.currentNeighborhoodObjectId = null;
			} else if ( currentLevel == "AREA" ) {
				globalDataInteractionObj.mapInteractionHandler.currentAreaObjectId = currentObject.OBJECT_ID;
				globalDataInteractionObj.mapInteractionHandler.currentNeighborhoodObjectId = null;
				currentObject.OBJECT_PARENT_IDS = globalDataInteractionObj.mapInteractionHandler.currentMapObjectId;
			} else if ( currentLevel == "NEIGHBORHOOD" ) {
				globalDataInteractionObj.mapInteractionHandler.currentNeighborhoodObjectId = currentObject.OBJECT_ID;
				currentObject.OBJECT_PARENT_IDS = globalDataInteractionObj.mapInteractionHandler.currentMapObjectId;
				currentObject.OBJECT_PARENT_IDS = currentObject.OBJECT_PARENT_IDS + '|' + globalDataInteractionObj.mapInteractionHandler.currentAreaObjectId;
			}
			globalDataInteractionObj.mapInteractionHandler.currentMapObject = currentObject;
		},
		findMapObject: function(mapTagName) {				
			if( typeof(mapTagName) == 'undefined' || mapTagName == null ) {
				mapTagName = globalDataInteractionObj.mapInteractionHandler.currentMap;
			}
			//console.log('mapTagName:' + mapTagName);
			//console.log(globalDataInteractionObj.mapInteractionHandler.mapLearningObjects);
			var elanMapObjectId = globalDataInteractionObj.mapInteractionHandler.getElanMapObjectId();
			var mapObject = globalDataInteractionObj.utilities.findOneByProperty(globalDataInteractionObj.mapInteractionHandler.mapLearningObjects, 'OBJECT_ID', elanMapObjectId);
			if(typeof(mapObject) == 'object' && mapObject != null) {
				mapObject.OBJECT_TAG = mapTagName;
				mapObject.OBJECT_HELP = true;
				mapObject.OBJECT_SHOW_INFO = false;
				mapObject.OBJECT_SHOW_NAV = false;				
				//mapObject.OBJECT_HELP_TEXT = mapObject['Help Text'];
				mapObject.OBJECT_HELP_TEXT = '<p class=\'text-right btn-close\'><span class=\'glyphicon glyphicon-remove-circle\' aria-hidden=\'true\'></span></p>';
				mapObject.OBJECT_HELP_TEXT += '<p>The ML Apprentice level will take you through six NYC areas, each composed of multiple neighborhoods.</p>';
				mapObject.OBJECT_HELP_TEXT += '<p>Click on the map to view an area. Click \'ENTER NEIGHBORHOODS\' to view the neighborhoods in that area. Click the \'NEXT\' and \'PREVIOUS\' buttons to move between neighborhoods within an area.</p>';
				mapObject.OBJECT_HELP_TEXT += '<p>Each neighborhood is a course. Click \'EXPERIENCE\' to enter the neighborhood and start the course. You may complete a course all at once, or save your progress and return at a later time.</p>';
				mapObject.OBJECT_HELP_TEXT += '<p>At the end of each course, you will take a final assessment&mdash;both online and offline. Successful completion certifies you to continue your journey.</p>';
				mapObject.OBJECT_HELP_TEXT = globalDataInteractionObj.utilities.escapeXml(mapObject.OBJECT_HELP_TEXT);
				
				var elanMapUnlockObjectId = globalDataInteractionObj.mapInteractionHandler.getElanMapUnlockObjectId();
				var userObjectStatus = globalDataInteractionObj.mapInteractionHandler.getNeighborhoodObjectStatus(elanMapUnlockObjectId);
				//console.log(userObjectStatus);
				if( userObjectStatus != 'locked' && userObjectStatus != 'open' ) {
					mapObject.CALL_TO_ACTION = 'CONTINUE YOUR JOURNEY';
				} else {
					mapObject.CALL_TO_ACTION = 'START YOUR JOURNEY';
				}
			}
			//console.log(mapObject);
			return mapObject;
		},
		findAreaObject: function(areaTagName) {				
			if( typeof(areaTagName) == 'undefined' || areaTagName == null ) {
				// Find first area in current map					
				var currentMapInfo = globalDataInteractionObj.mapInteractionHandler.getMapInfo();
				//console.log(currentMapInfo);
				var areas = globalDataInteractionObj.utilities.findAllByProperty(currentMapInfo, 'parent_id', '0');
				//console.log(areas);
				
				var currentArea = globalDataInteractionObj.mapInteractionHandler.currentArea;
				var areaInfo = {};
				if( typeof(currentArea) != 'undefined' && currentArea != null ) {
					areaInfo = globalDataInteractionObj.utilities.findOneByProperty(areas, 'cat_name', currentArea, 'AREA');
				} else {
					areaInfo = globalDataInteractionObj.utilities.sortByProperty(areas, 'unlockorder')[0];	
				}					
				
				//console.log(areaInfo);
				areaTagName = areaInfo.cat_name;
				
				// To highlight area when journey starts or continue
				globalDataInteractionObj.mapInteractionHandler.doEventChanges('autoHash', areaInfo.cat_url_title, areaInfo.cat_name);
			}
			//console.log('areaTagName:' + areaTagName);
			var areaObject = globalDataInteractionObj.utilities.findMapArea(globalDataInteractionObj.mapInteractionHandler.mapLearningObjects, areaTagName);
			if(typeof(areaObject) == 'object' && areaObject != null) {
				areaObject.OBJECT_TAG = areaTagName;
				areaObject.OBJECT_HELP = false;
				areaObject.OBJECT_SHOW_INFO = false;
				areaObject.OBJECT_SHOW_NAV = false;				
				areaObject.CALL_TO_ACTION = 'ENTER NEIGHBORHOODS';
			}
			//console.log(areaObject);			
			return areaObject;
		},
		findNeighborhoodObject: function(neighborhoodTagName) {								
			var currentMapInfo = globalDataInteractionObj.mapInteractionHandler.getMapInfo();
			//console.log(currentMapInfo);
			if( typeof(neighborhoodTagName) == 'undefined' || neighborhoodTagName == null ) {
				// Find first neighborhood in current area										
				var neighborhoods = globalDataInteractionObj.utilities.findAllByProperty(currentMapInfo, 'parent_name', globalDataInteractionObj.mapInteractionHandler.currentArea);					
				//console.log(neighborhoods);
				
				var currentNeighborhood = globalDataInteractionObj.mapInteractionHandler.currentNeighborhood;
				//console.log(currentNeighborhood);
				var neighborhoodInfo = {};
				if( typeof(currentNeighborhood) != 'undefined' && currentNeighborhood != null ) {
					neighborhoodInfo = globalDataInteractionObj.utilities.findOneByProperty(neighborhoods, 'cat_name', currentNeighborhood, 'NEIGHBORHOOD');
				} else {
					neighborhoodInfo = globalDataInteractionObj.utilities.sortByProperty(neighborhoods, 'unlockorder')[0];
				}
				
				//console.log(neighborhoodInfo);
				neighborhoodTagName = neighborhoodInfo.cat_name;
			} else {
				var neighborhoodInfo = globalDataInteractionObj.utilities.findOneByProperty(currentMapInfo, 'cat_name', neighborhoodTagName, 'NEIGHBORHOOD');
				var neighborhoods = globalDataInteractionObj.utilities.findAllByProperty(currentMapInfo, 'parent_url_title', neighborhoodInfo.parent_url_title);
				//console.log(neighborhoods);
			}
			//console.log('neighborhoodTagName:' + neighborhoodTagName);
			var neighborhoodObject = globalDataInteractionObj.utilities.findMapNeighborhood(globalDataInteractionObj.mapInteractionHandler.mapLearningObjects, neighborhoodTagName);
			//console.log(neighborhoodObject);
			if(typeof(neighborhoodObject) == 'object' && neighborhoodObject != null) {
				neighborhoodObject.OBJECT_TAG = neighborhoodTagName;
				neighborhoodObject.OBJECT_HELP = false;		
				neighborhoodObject.OBJECT_SHOW_INFO = false;
				neighborhoodObject.OBJECT_NUMBER_OF_STOPS = neighborhoodInfo.number_of_stops || '';
				neighborhoodObject.OBJECT_MINUTES_TO_FINISH = neighborhoodInfo.minutes_to_finish || '';
				if( neighborhoodObject.OBJECT_NUMBER_OF_STOPS != '' && neighborhoodObject.OBJECT_MINUTES_TO_FINISH != '' ) {
					neighborhoodObject.OBJECT_SHOW_INFO = true;
				}
				if( neighborhoods.length > 1 ) {
					neighborhoodObject.OBJECT_SHOW_NAV = true;
				} else {
					neighborhoodObject.OBJECT_SHOW_NAV = false;
				}					
			}
			//console.log(neighborhoodObject);			
			return neighborhoodObject;
		},		
		setObjectPin: function() {
			//Display pin
			//console.log(globalDataInteractionObj.mapInteractionHandler.currentMapObject.OBJECT_LEVEL);
			if( jQuery('#vmap svg').length > 0 ) {
				var neighborhoodPins = $.extend( {}, globalDataInteractionObj.mapInteractionHandler.getPins());
				if( globalDataInteractionObj.mapInteractionHandler.currentMapObject.OBJECT_LEVEL == 'NEIGHBORHOOD') {
					var currentNeighborhood = globalDataInteractionObj.mapInteractionHandler.currentNeighborhood;
					var currentMapInfo = globalDataInteractionObj.mapInteractionHandler.getMapInfo();
					var currentNeighborhoodInfo = globalDataInteractionObj.utilities.findOneByProperty(currentMapInfo, 'cat_name', currentNeighborhood, 'NEIGHBORHOOD');
					
					var pinImageName = 'pin-select-' + currentNeighborhoodInfo.parent_url_title + '.png';
					var pingImagePath = globalDataInteractionObj.objectProperties.appRoot+"images/marker/"+pinImageName;
					var pinContent = "<div class='map-pin'><span class='pin-img' ";
					pinContent += "style=\"background-image: url('"+pingImagePath+"')\"";
					pinContent += ">";
					pinContent += "</span></div>";
					neighborhoodPins[currentNeighborhoodInfo.cat_url_title] = pinContent;
				}
				globalDataInteractionObj.mapInteractionHandler.displayPins(neighborhoodPins);
			}
		},
		displayPins: function(neighborhoodPins) {
			jQuery('#vmap').vectorMap('removePins');
			//console.log(neighborhoodPins);
			if( typeof(neighborhoodPins) == 'undefined') {	
				neighborhoodPins = globalDataInteractionObj.mapInteractionHandler.getPins();
			}
			globalDataInteractionObj.mapInteractionHandler.currentJQVMapObject.placePins(neighborhoodPins, 'content');
			
			//set pins position as per device
			/*
			var is_iPad = globalDataInteractionObj.objectProperties.isIPad;
			if( !is_iPad ) {
				
				var journeyContentWidth = $( "div.journey-content" ).width();
				//console.log(journeyContentWidth);
				if( journeyContentWidth > 0) {				
					var mapInfoWidth = $( "div.journey-content div.map-info-container" ).width();
					//console.log(mapInfoWidth);
					var documentWidth = $( document ).width();
					//console.log(documentWidth);
					if( documentWidth > journeyContentWidth ) {
						var temp = (documentWidth - journeyContentWidth) / 2;
						mapInfoWidth = mapInfoWidth + temp;
					}
					//console.log(mapInfoWidth);
					$( ".map-container div#vmap .jqvmap-pin" ).css( "margin-left", "-"+mapInfoWidth+"px");
				}				
			} else {
				var marginLeft = parseInt($( ".map-container div#vmap .jqvmap-pin" ).css( "margin-left")) + 10;
				$( ".map-container div#vmap .jqvmap-pin" ).css( "margin-left", "-"+marginLeft+"px");				
			}
			*/
		},
		displayObjectInfo: function(objectLevel, objectInfo) {
			globalDataInteractionObj.mapInteractionHandler.setCurrentObject(objectLevel, objectInfo);
			globalDataInteractionObj.handlebarsUtils.setTemplates('map-info-template', objectInfo);				
			
			$('[data-toggle="popover"]').popover({container: 'body'});				
			$('[data-toggle="popover"]').on( 'shown.bs.popover' , function() {
				$('.popover-content .btn-close span').on( 'click' , function() {
					$('[data-toggle="popover"]').popover('hide');
				});
			});
			
			//Set height for map content		
			globalDataInteractionObj.mapInteractionHandler.setContentHeight();
			globalDataInteractionObj.mapInteractionHandler.setObjectPin();
		},
		displayMapData: function(mapTagName) {
			globalDataInteractionObj.ajaxUtilities.loading('div.map-info-container');
			var mapObject = globalDataInteractionObj.mapInteractionHandler.findMapObject(mapTagName);				
			if(typeof(mapObject) == 'object' && mapObject != null) {				
				globalDataInteractionObj.mapInteractionHandler.currentMap = mapObject.OBJECT_TAG;					
				globalDataInteractionObj.mapInteractionHandler.displayObjectInfo('MAP', mapObject);
			
				$('a#mapCallToAction').click(function() {
					var currentArea = globalDataInteractionObj.mapInteractionHandler.currentArea;
					var currentNeighborhood = globalDataInteractionObj.mapInteractionHandler.currentNeighborhood;
					//console.log('currentArea: ' + currentArea);
					//console.log('currentNeighborhood: ' + currentNeighborhood);
					if( typeof(currentArea) != 'undefined' && currentArea != null 
						&& typeof(currentNeighborhood) != 'undefined' && currentNeighborhood != null ) {
						//This line of code needed to highlight area when journey continue
						var currentAreaObject = globalDataInteractionObj.mapInteractionHandler.findAreaObject();
						globalDataInteractionObj.mapInteractionHandler.currentAreaObjectId = currentAreaObject.OBJECT_ID;
						globalDataInteractionObj.mapInteractionHandler.displayNeighborhoodData(currentNeighborhood);
					} else {
						globalDataInteractionObj.mapInteractionHandler.displayAreaData();
					}
				});
			}
		},
		displayAreaData: function(areaTagName) {
			$('[data-toggle="popover"]').popover('hide');
			globalDataInteractionObj.ajaxUtilities.loading('div.map-info-container');
			//console.log('areaTagName: ' + areaTagName);
			var areaObject = globalDataInteractionObj.mapInteractionHandler.findAreaObject(areaTagName);
			//console.log(areaObject);
			if(typeof(areaObject) == 'object' && areaObject != null) {										
				globalDataInteractionObj.mapInteractionHandler.currentArea = areaObject.OBJECT_TAG;						
				var currentMapInfo = globalDataInteractionObj.mapInteractionHandler.getMapInfo();
				var neighborhoods = globalDataInteractionObj.utilities.findAllByProperty(currentMapInfo, 'parent_name', areaObject.OBJECT_TAG);
				//console.log(neighborhoods);
				//If area has only one neighborhood then display neighborhood
				if(neighborhoods.length == 1) {
					globalDataInteractionObj.mapInteractionHandler.currentAreaObjectId = areaObject.OBJECT_ID;
					globalDataInteractionObj.mapInteractionHandler.displayNeighborhoodData();
				} else {
					location.hash = 'journey|' + areaObject.OBJECT_TAG;
					globalDataInteractionObj.mapInteractionHandler.displayObjectInfo('AREA', areaObject);
					
					$('a#mapCallToAction').click(function() {
						globalDataInteractionObj.mapInteractionHandler.displayNeighborhoodData();				
					});
				}
			}	
		},
		displayNeighborhoodData: function(neighborhoodTagName) {				
			globalDataInteractionObj.ajaxUtilities.loading('div.map-info-container');
			var neighborhoodObject = globalDataInteractionObj.mapInteractionHandler.findNeighborhoodObject(neighborhoodTagName);
			if(typeof(neighborhoodObject) == 'object' && neighborhoodObject != null) {
				location.hash = 'journey|' + globalDataInteractionObj.mapInteractionHandler.currentArea + '|' + neighborhoodObject.OBJECT_TAG;					
				globalDataInteractionObj.mapInteractionHandler.currentNeighborhood = neighborhoodObject.OBJECT_TAG;
				
				var userObjectStatus = globalDataInteractionObj.mapInteractionHandler.getNeighborhoodObjectStatus(neighborhoodObject.OBJECT_ID);
				//console.log(userObjectStatus);
				if( userObjectStatus == 'locked' ) {
					neighborhoodObject.CALL_TO_ACTION = 'LOCKED';
				} else {
					neighborhoodObject.CALL_TO_ACTION = 'EXPERIENCE';
				}
				//console.log(neighborhoodObject);					
				globalDataInteractionObj.mapInteractionHandler.displayObjectInfo('NEIGHBORHOOD', neighborhoodObject);
				
				if( neighborhoodObject.CALL_TO_ACTION != 'LOCKED' ) {
					$('a#mapCallToAction').click(function() {
						$('a#mapCallToAction').css("pointer-events", "none");
						globalDataInteractionObj.utilities.launchNeighborhoodCourse();
					});
				}
				
				$('a#btn-previous').click(function() {
					globalDataInteractionObj.mapInteractionHandler.previousNeighborhood();				
				});
				
				$('a#btn-next').click(function() {
					globalDataInteractionObj.mapInteractionHandler.nextNeighborhood();				
				});
			}	
		},			
		previousNeighborhood: function() {
			var currentMapInfo = globalDataInteractionObj.mapInteractionHandler.getMapInfo();
			var currentArea = globalDataInteractionObj.mapInteractionHandler.currentArea;
			var currentNeighborhood = globalDataInteractionObj.mapInteractionHandler.currentNeighborhood;
			var neighborhoods = globalDataInteractionObj.utilities.findAllByProperty(currentMapInfo, 'parent_name', currentArea);
			neighborhoods = globalDataInteractionObj.utilities.sortByProperty(neighborhoods, 'unlockorder');
			var currentIndex = globalDataInteractionObj.utilities.findIndexByProperty(neighborhoods, 'cat_name', currentNeighborhood);				
			var previousIndex = currentIndex - 1;
			if(previousIndex < 0) {
				previousIndex = neighborhoods.length - 1;
			}
			var neighborhoodTagName = neighborhoods[previousIndex].cat_name;				
			globalDataInteractionObj.mapInteractionHandler.displayNeighborhoodData(neighborhoodTagName);
		},
		nextNeighborhood: function() {
			var currentMapInfo = globalDataInteractionObj.mapInteractionHandler.getMapInfo();
			var currentArea = globalDataInteractionObj.mapInteractionHandler.currentArea;
			var currentNeighborhood = globalDataInteractionObj.mapInteractionHandler.currentNeighborhood;
			var neighborhoods = globalDataInteractionObj.utilities.findAllByProperty(currentMapInfo, 'parent_name', currentArea);
			neighborhoods = globalDataInteractionObj.utilities.sortByProperty(neighborhoods, 'unlockorder');
			var currentIndex = globalDataInteractionObj.utilities.findIndexByProperty(neighborhoods, 'cat_name', currentNeighborhood);				
			var nextIndex = currentIndex + 1;
			if(nextIndex == neighborhoods.length) {
				nextIndex = 0;
			}
			var neighborhoodTagName = neighborhoods[nextIndex].cat_name;				
			globalDataInteractionObj.mapInteractionHandler.displayNeighborhoodData(neighborhoodTagName);

			// Start new pin drop logic

			// var theID = $('#jqvmap1_' + currentNeighborhood.toLowerCase().replace(' ', ''));
			// var thePin = $('#drop-pin');

			// thePin.css({
			//     top: theID.offset().top,
			//     right: theID.offset().left
			// }).show();
			// var coords = PinDropper.getCoordinates(currentNeighborhood);
			// console.log(coords);
			// PinDropper.placePin(coords);

		},		
		displayCurrentData: function() {
			
			var currentMapInfo = globalDataInteractionObj.mapInteractionHandler.getMapInfo();
			var currentMap = globalDataInteractionObj.mapInteractionHandler.currentMap;
			var currentArea = globalDataInteractionObj.mapInteractionHandler.currentArea;
			var currentNeighborhood = globalDataInteractionObj.mapInteractionHandler.currentNeighborhood;

			//console.log('currentMap:' + currentMap);
			//console.log('currentArea:' + currentArea);
			//console.log('currentNeighborhood:' + currentNeighborhood);
			
			// Loading becase have to set currentMapObjectId
			globalDataInteractionObj.mapInteractionHandler.displayMapData(currentMap);
			
			// Loading becase have to set currentAreaObjectId
			if( typeof(currentArea) != 'undefined' && currentArea != null ) {
				globalDataInteractionObj.mapInteractionHandler.displayAreaData(currentArea);
			}

			// Loading becase have to set currentNeighborhoodObjectId
			if( typeof(currentNeighborhood) != 'undefined' && currentNeighborhood != null ) {
				globalDataInteractionObj.mapInteractionHandler.displayNeighborhoodData(currentNeighborhood);
			}				
			
			
			globalDataInteractionObj.mapInteractionHandler.loadMap();

			if( typeof(currentNeighborhood) != 'undefined' && currentNeighborhood != null ) {
				var neighborhoodInfo = globalDataInteractionObj.utilities.findOneByProperty(currentMapInfo, 'cat_name', currentNeighborhood, 'NEIGHBORHOOD');
				//console.log(neighborhoodInfo);
				globalDataInteractionObj.mapInteractionHandler.doEventChanges('autoHash', neighborhoodInfo.parent_url_title, neighborhoodInfo.parent_name);
				globalDataInteractionObj.mapInteractionHandler.setObjectPin();
			}
			else if( typeof(currentArea) != 'undefined' && currentArea != null ) {				
				var areaInfo = globalDataInteractionObj.utilities.findOneByProperty(currentMapInfo, 'cat_name', currentArea, 'AREA');
				globalDataInteractionObj.mapInteractionHandler.doEventChanges('autoHash', areaInfo.cat_url_title, areaInfo.cat_name);
			}
		},
		doEventChanges: function(eventType, code, region) {				
			if(eventType == 'regionMouseOut') {
				var selectedColors = globalDataInteractionObj.mapInteractionHandler.getSelectedColors();	
				jQuery('#vmap').vectorMap('set', 'colors', selectedColors);
			} else {
				var currentMapInfo = globalDataInteractionObj.mapInteractionHandler.getMapInfo();
				var areaInfo = null;
				
				//console.log(eventType);
				if( eventType == 'autoHash') {
					//console.log(code);
					areaInfo = globalDataInteractionObj.utilities.findOneByProperty(currentMapInfo, 'cat_url_title', code, 'AREA');
				} else {
					var neighborhoodInfo = globalDataInteractionObj.utilities.findOneByProperty(currentMapInfo, 'cat_url_title', code, 'NEIGHBORHOOD');
					//console.log(neighborhoodInfo);
					if( typeof(neighborhoodInfo) != 'undefined' && neighborhoodInfo != null ) {					
						areaInfo = globalDataInteractionObj.utilities.findOneByProperty(currentMapInfo, 'cat_url_title', neighborhoodInfo.parent_url_title, 'AREA');
					}
				}
				
				//console.log(areaInfo);
				if( typeof(areaInfo) != 'undefined' && areaInfo != null ) {						
					var neighborhoods = globalDataInteractionObj.utilities.findAllByProperty(currentMapInfo, 'parent_url_title', areaInfo.cat_url_title);
					//console.log(neighborhoods);
					var selectedNeighborhoods = [];
					$.each( neighborhoods, function( nkey, nvalue ) {
						selectedNeighborhoods.push(nvalue.cat_url_title);
					});
					
					//console.log(selectedNeighborhoods);							
					//console.log('eventType - ' + eventType);
					if( eventType == 'autoHash') {							
						globalDataInteractionObj.mapInteractionHandler.setRegionBorderColors(eventType, areaInfo.cat_url_title);
						globalDataInteractionObj.mapInteractionHandler.setRegionColors(eventType, areaInfo.cat_url_title, selectedNeighborhoods, currentMapInfo);
					} else if( eventType == 'regionClick') {
						globalDataInteractionObj.mapInteractionHandler.currentNeighborhood = null;
						globalDataInteractionObj.mapInteractionHandler.displayAreaData(areaInfo.cat_name);							
						globalDataInteractionObj.mapInteractionHandler.setRegionBorderColors(eventType, areaInfo.cat_url_title);
						globalDataInteractionObj.mapInteractionHandler.setRegionColors(eventType, areaInfo.cat_url_title, selectedNeighborhoods, currentMapInfo);
					} else if ( eventType == 'regionMouseOver') {
						globalDataInteractionObj.mapInteractionHandler.setRegionColors(eventType, areaInfo.cat_url_title, selectedNeighborhoods, neighborhoods);
					}
				}
			}
		},
		displayAdditionalContent: function(mapObject) {
			var additionalContent = globalDataInteractionObj.mapInteractionHandler.getAdditionalContent();
			$.each(additionalContent, function( key, contentObj ) {
				var text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
				text.setAttribute('transform', contentObj.transform);
									
				$.each(contentObj.content, function(cindex, cvalue) {
					var node = document.createElementNS('http://www.w3.org/2000/svg', 'tspan');
					node.setAttribute('x', cvalue.x);
					node.setAttribute('y', cvalue.y);
					node.setAttribute('class', cvalue.class);
					node.textContent = cvalue.text;
					if( contentObj.hasOwnProperty("region") ) {
						node.setAttribute('id', mapObject.getCountryId(contentObj.region) + '_text' + cindex);
						node.onclick = function() {								
							var temp = $( this ).attr('id').split("_");
							temp.pop();
							temp = temp.join("_");
							$( "#"+temp ).trigger("click");
						};							
					}
					
					text.appendChild(node);
				});
				
				jQuery('#vmap svg g').append(text);
				
				
			});
		},
		getMapInfo: function() {
			//TODO: Change this line of code to handle multiple maps
			return globalDataInteractionObj.mlApprenticeHandler.mapInfo;
		},
		getElanMapObjectId: function() {
			//TODO: Change this line of code to handle multiple maps
			return globalDataInteractionObj.mlApprenticeHandler.elanMapObjectId;
		},
		getElanMapUnlockObjectId: function() {
			//TODO: Change this line of code to handle multiple maps
			return globalDataInteractionObj.mlApprenticeHandler.elanMapUnlockObjectId;
		},
		getOriginalColors: function() {
			//TODO: Change this line of code to handle multiple maps
			return globalDataInteractionObj.mlApprenticeHandler.originalColors;
		},
		getDarkColors: function() {
			//TODO: Change this line of code to handle multiple maps
			return globalDataInteractionObj.mlApprenticeHandler.darkColors;
		},
		getPins: function() {
			//TODO: Change this line of code to handle multiple maps
			$.each(globalDataInteractionObj.mlApprenticeHandler.pins, function(key, value) {
				globalDataInteractionObj.mlApprenticeHandler.pins[key] = globalDataInteractionObj.utilities.escapeXml(value);
			});
			return globalDataInteractionObj.mlApprenticeHandler.pins;
		},
		setPin: function(key, value) {
			//TODO: Change this line of code to handle multiple maps
			globalDataInteractionObj.mlApprenticeHandler.pins[key] = globalDataInteractionObj.utilities.escapeXml(value);				
		},
		getAdditionalContent: function() {
			//TODO: Change this line of code to handle multiple maps
			return globalDataInteractionObj.mlApprenticeHandler.additionalContent;
		},		
		getSelectedColors: function() {
			//TODO: Change this line of code to handle multiple maps
			return globalDataInteractionObj.mlApprenticeHandler.selectedColors;
		},
		setSelectedColors: function(selectedColors) {
			//TODO: Change this line of code to handle multiple maps
			globalDataInteractionObj.mlApprenticeHandler.selectedColors = selectedColors;
		},
		setRegionBorderColors: function(eventType, selectedArea) {
			//TODO: Change this line of code to handle multiple maps
			var newColors = globalDataInteractionObj.mlApprenticeHandler.getRegionBorderColors(selectedArea);
			
			jQuery('#vmap').vectorMap('set', 'colors', newColors);
			// This line used to keep track of latest color and revert back to it after mouse out
			if( eventType == 'regionClick' || eventType == 'autoHash' ) {
				globalDataInteractionObj.mapInteractionHandler.setSelectedColors(newColors);
			}
		},
		setRegionColors: function(eventType, selectedArea, selectedNeighborhoods, colorToNeighborhoods) {		
			//console.log(selectedNeighborhoods);
			//console.log(colorToNeighborhoods);
			var selectedColors = globalDataInteractionObj.mapInteractionHandler.getSelectedColors();
			var originalColors = globalDataInteractionObj.mapInteractionHandler.getOriginalColors();
			var darkColors = globalDataInteractionObj.mapInteractionHandler.getDarkColors();				
			var newColors = $.extend( {}, selectedColors);
			
			$.each( colorToNeighborhoods, function( key, value ) {
				if( value.parent_id != 0) {
					var name = value.cat_url_title;				
					if( jQuery.inArray(name, selectedNeighborhoods) != -1 ) {									
						newColors[name] = originalColors[name];
					} else {
						newColors[name] = darkColors[name];
					}
				}
			});
			jQuery('#vmap').vectorMap('set', 'colors', newColors);
			// This line used to keep track of latest color and revert back to it after mouse out
			if( eventType == 'regionClick' || eventType == 'autoHash') {
				globalDataInteractionObj.mapInteractionHandler.setSelectedColors(newColors);
			}	
		},			
		loadMap: function() {
			
			var is_iPad = globalDataInteractionObj.objectProperties.isIPad;
			
			var mapObject = jQuery('#vmap').vectorMap({
				map: 'ny_usa_en', //Change this line of code to handle multiple maps
				backgroundColor: '#F3F2EA',
				colors: globalDataInteractionObj.mapInteractionHandler.getOriginalColors(),
				enableZoom: (!is_iPad),
				showTooltip: false,
				showLabels: false,
				regionSelectable: false,
				hoverOpacity: 1,
				series: {
					regions: [{
						attribute: 'fill'				
					}]
				},			
				pins: {},
				pinMode: 'content',
				onLoad: function(event, map) {
					globalDataInteractionObj.isMapLoaded = true;
					
					//console.log(map);
					globalDataInteractionObj.mapInteractionHandler.currentJQVMapObject = map;
					globalDataInteractionObj.mapInteractionHandler.displayAdditionalContent(map);
					//map.canvas.applyTransformParams(0.5, 0, 0);
					//jQuery('#vmap').trigger('drag');
					
					/*
					var mapElement = document.getElementById("vmap");
					mapElement.addEventListener('touchmove', function(e) {
						jQuery('#vmap').trigger('drag');
					}, false);
					*/
					
					//To set pins as per status
					var currentNeighborhood = globalDataInteractionObj.mapInteractionHandler.getNeighborhoodObjectStatus();
					//console.log('currentNeighborhood: ' + currentNeighborhood);
					// This is to display the destination and destination image on the profile page.
					globalDataInteractionObj.userData.displayNextDestination();
					globalDataInteractionObj.userData.displayPassportStamps();
					// This is to display the journey accordion on the profile page.
					globalDataInteractionObj.userData.displayJourneyAccordion();
				},
				onRegionOver: function(event, code, region) {				
					//console.log('onRegionOver - ' + event + '-' + code + ' - ' + region);
					//console.log(event);
					globalDataInteractionObj.mapInteractionHandler.doEventChanges(event.type, code, region);
				},
				onRegionOut: function(event, code, region) {				
					//console.log('onRegionOut - ' + event + '-' + code + ' - ' + region);
					//console.log(event);
					//console.log(selectedColors);
					globalDataInteractionObj.mapInteractionHandler.doEventChanges(event.type, code, region);				
				},
				onRegionClick: function(event, code, region) {
					event.preventDefault();
					//console.log('onRegionClick - ' + event + '-' + code + ' - ' + region);
					//console.log(event);
					globalDataInteractionObj.mapInteractionHandler.doEventChanges(event.type, code, region);
				},
				onResize: function(event, width, height) {						
					setTimeout(function()  {
						//alert("width:" + width);
						//alert("height:" + height);
						globalDataInteractionObj.mapInteractionHandler.setObjectPin();
					},200);
				}	
			});
		},
		resetMap: function() {
			//console.log('resetMap');
			location.hash = 'journey';
			
			var mapObject = globalDataInteractionObj.mapInteractionHandler.currentJQVMapObject;
			mapObject.reset();
			mapObject.zoomCurStep = 1;			
			
			globalDataInteractionObj.mapInteractionHandler.currentArea = null;
			globalDataInteractionObj.mapInteractionHandler.currentNeighborhood = null;
			
			var currentMap = globalDataInteractionObj.mapInteractionHandler.currentMap;
			globalDataInteractionObj.mapInteractionHandler.displayMapData(currentMap);
			
			var originalColors = globalDataInteractionObj.mapInteractionHandler.getOriginalColors();
			globalDataInteractionObj.mapInteractionHandler.setSelectedColors(originalColors);
			jQuery('#vmap').vectorMap('set', 'colors', originalColors);
			
			var currentNeighborhood = globalDataInteractionObj.mapInteractionHandler.getNeighborhoodObjectStatus();
			//console.log('currentNeighborhood: ' + currentNeighborhood);			
		},
		mapDataInit: function() {			
			globalDataInteractionObj.mapInteractionHandler.fetchMapLearningObjects();				
		},
		mapInit: function() {
			//TODO: Change this line of code to handle multiple maps
			globalDataInteractionObj.mapInteractionHandler.currentMap = elanTags.mlapprentice;
			
			//Commented out because on refresh user goes back to home page
			/*			
			if(location.hash != '' && location.hash != '#') {
				var page = location.hash;
				page = page.replace('#', '');
				page = page.split("|");
				
				//console.log('page length:' + page.length);
				if( typeof(page[0]) != 'undefined' && page[0] == 'journey') {						
					//console.log('page:' + page[0]);
				
					if( typeof(page[1]) != 'undefined' && page[1] != '' ) {
						globalDataInteractionObj.mapInteractionHandler.currentArea = page[1];							
					}					
					if( typeof(page[2]) != 'undefined' && page[2] != '' ) {
						globalDataInteractionObj.mapInteractionHandler.currentNeighborhood = page[2];						
					}
				}
			}
			*/
			globalDataInteractionObj.mapInteractionHandler.loadSlideOutPanel();
		}
	},
	mlApprenticeHandler: {
		mapInfo: mlapprentice,
		elanMapObjectId: journeys.mlapprentice.elan_map_object_id,
		elanMapUnlockObjectId: journeys.mlapprentice.first_unlock_object_id,
		originalColors: {
			"financialdistrict": "#F3F2EA",
			"st1": "#9CC0DC",
			"st2": "#BDD7EF",
			"chinatown": "#B1B0AE",
			"tribeca": "#CACAC8",
			"lowereastside": "#999792",
			"eastvillage": "#D3B4D6",
			"greenwichvillage": "#786578",
			"soho": "#997E99",
			"westvillage": "#A8A1CD",
			"thehighlineneighborhood": "#9C7C63",
			"chelsea": "#8683B0",
			"gramercy": "#A79CA7",
			"murrayhill": "#E3CA68",
			"garmentdistrict": "#FBE381",
			"hellskitchen": "#FAEEBF",
			"clinton": "#87B5CB",
			"columbuscircle": "#A9D7ED",
			"midtowneast": "#36718C",
			"theaterdistrict": "#5D91A9",
			"upperwestsideneighborhood": "#287547",
			"centralpark": "#4A9468",
			"uppereastside": "#98CEB3",
			"yorkville": "#CDEDDD",
			"st24l1": "#FFFFFF",
			"st24l2": "#FFFFFF",
			"st24l3": "#FFFFFF",
			"st24l4": "#FFFFFF",
			"st24l5": "#FFFFFF",
			"st24l6": "#FFFFFF",
			"st24l7": "#FFFFFF"
		},
		darkColors: {
			"financialdistrict": "#3d3d3b",
			"st1": "#9CC0DC",
			"st2": "#BDD7EF",
			"chinatown": "#2c2c2c",
			"tribeca": "#333333",
			"lowereastside": "#262626",
			"eastvillage": "#352d36",
			"greenwichvillage": "#1e191e",
			"soho": "#262026",
			"westvillage": "#2a2833",
			"thehighlineneighborhood": "#271f19",
			"chelsea": "#22212c",
			"gramercy": "#2a272a",
			"murrayhill": "#39331a",
			"garmentdistrict": "#3f3920",
			"hellskitchen": "#3f3c30",
			"clinton": "#222d33",
			"columbuscircle": "#2a363b",
			"midtowneast": "#0e1c23",
			"theaterdistrict": "#17242a",
			"upperwestsideneighborhood": "#0a1d12",
			"centralpark": "#13251a",
			"uppereastside": "#26342d",
			"yorkville": "#333b37",
			"st24l1": "#404040",
			"st24l2": "#404040",
			"st24l3": "#404040",
			"st24l4": "#404040",
			"st24l5": "#404040",
			"st24l6": "#404040",
			"st24l7": "#404040"
		},
		pins: {
			'financialdistrict': "<div class='map-pin'><span class='pin-img'></span></div>",
			'chinatown': "<div class='map-pin'><span class='pin-img'></span></div>",
			'tribeca': "<div class='map-pin'><span class='pin-img'></span></div>",
			'lowereastside': "<div class='map-pin'><span class='pin-img'></span></div>",
			'eastvillage': "<div class='map-pin'><span class='pin-img'></span></div>",
			'greenwichvillage': "<div class='map-pin'><span class='pin-img'></span></div>",
			'soho': "<div class='map-pin'><span class='pin-img'></span></div>",
			'westvillage': "<div class='map-pin'><span class='pin-img'></span></div>",
			'thehighlineneighborhood': "<div class='map-pin'><span class='pin-img'></span></div>",
			'chelsea': "<div class='map-pin'><span class='pin-img'></span></div>",
			'gramercy': "<div class='map-pin'><span class='pin-img'></span></div>",
			'murrayhill': "<div class='map-pin'><span class='pin-img'></span></div>",
			'garmentdistrict': "<div class='map-pin'><span class='pin-img'></span></div>",
			'hellskitchen': "<div class='map-pin'><span class='pin-img'></span></div>",
			'clinton': "<div class='map-pin'><span class='pin-img'></span></div>",
			'columbuscircle': "<div class='map-pin'><span class='pin-img'></span></div>",
			'midtowneast': "<div class='map-pin'><span class='pin-img'></span></div>",
			'theaterdistrict': "<div class='map-pin'><span class='pin-img'></span></div>",
			'upperwestsideneighborhood': "<div class='map-pin'><span class='pin-img'></span></div>",
			'centralpark': "<div class='map-pin'><span class='pin-img'></span></div>",
			'uppereastside': "<div class='map-pin'><span class='pin-img'></span></div>",
			'yorkville': "<div class='map-pin'><span class='pin-img'></span></div>"
		},
		additionalContent: [
			{
				"region": "thehighlineneighborhood",
				"transform": "matrix(0.2939 -0.9558 0.9558 0.2939 480.6837 589.4078)",
				"content": [
					{"text": "The High Line", "x": 0, "y": 0, "class": "st25 st26 highline-txt"},
					{"text": "The Coach Brand", "x": -24.1, "y": 18, "class": "st27 st26 highline-txt"},
				]
			},
			{
				"region": "columbuscircle",
				"transform": "matrix(0.8895 0.457 -0.457 0.8895 645.2094 186.5546)",
				"content": [
					{"text": "Columbus Circle", "x": 11, "y": 0, "class": "st25 st28 midtown-txt"},
					{"text": "Modern Luxury", "x": 0, "y": 14, "class": "st27 st28 midtown-txt"},
					{"text": "Store Tour", "x": 13, "y": 26.4, "class": "st27 st28 midtown-txt"}
				]
			},
			{
				"region": "garmentdistrict",
				"transform": "matrix(0.4905 -0.8715 0.8715 0.4905 651.1349 483.1003)",
				"content": [
					{"text": "Garment District", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "Women's Bags 101", "x": -16.9, "y": 18, "class": "st27 st26"}
				]
			},
			{
				"region": "murrayhill",
				"transform": "matrix(0.4483 -0.8939 0.8939 0.4483 782.1896 534.5327)",
				"content": [
					{"text": "Murray Hill", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "Men's Bags 101", "x": -20.6, "y": 18, "class":"st27 st26"}
				]
			},
			{
				"region": "hellskitchen",
				"transform": "matrix(0.4952 -0.8688 0.8688 0.4952 548.3871 413.2535)",
				"content": [
					{"text": "Hell's Kitchen", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "SLGs 101", "x": 12, "y": 18, "class":"st27 st26"}
				]
			},
			{
				"region": "theaterdistrict",
				"transform": "matrix(0.4832 -0.8755 0.8755 0.4832 705.0934 334.658)",
				"content": [
					{"text": "Theater District", "x": 0, "y": 0, "class": "st25 st29"},
					{"text": "The Power", "x": 7, "y": 16.7, "class":"st27 st29"},
					{"text": "of THREE", "x": 13.8, "y": 31.5, "class":"st27 st29"}
				]
			},				
			{
				"region": "midtowneast",
				"transform": "matrix(0.8793 0.4762 -0.4762 0.8793 831.5735 335.053)",
				"content": [
					{"text": "Midtown East", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "The Modern Luxury", "x": -30, "y": 18, "class":"st27 st26"},
					{"text": "Welcome", "x": 6.9, "y": 34, "class":"st27 st26"}
				]
			},
			{
				"region": "clinton",
				"transform": "matrix(0.877 0.4804 -0.4804 0.877 628.8459 249.6925)",
				"content": [
					{"text": "Clinton", "x": 0, "y": 0, "class": "st25 st30"},
					{"text": "Hosting multiple", "x": -38.0, "y": 14.8, "class":"st27 st30"},
					{"text": "customers", "x": -16.6, "y": 28, "class":"st27 st30"}
				]
			},
			{
				"region": "chelsea",
				"transform": "matrix(0.8847 0.4662 -0.4662 0.8847 596.7166 579.8589)",
				"content": [
					{"text": "Chelsea", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "Inspiring on", "x": -25.1, "y": 18, "class":"st27 st26"},
					{"text": "the brand", "x": -15.9, "y": 34, "class":"st27 st26"}
				]
			},   
			{
				"region": "soho",
				"transform": "matrix(0.8512 0.5249 -0.5249 0.8512 530.3207 842.9035)",
				"content": [
					{"text": "Soho", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "Leather 101", "x": -28.9, "y": 18, "class":"st27 st26"}
				]
			},   
			{
				"region": "westvillage",
				"transform": "matrix(0.5028 -0.8644 0.8644 0.5028 497.0017 738.5007)",
				"content": [
					{"text": "West Village", "x": 0, "y": 0, "class": "st25 st31"},
					{"text": "Storytelling", "x": -11, "y": 16.5, "class":"st27 st31"}
				]
			},   
			{
				"region": "greenwichvillage",
				"transform": "matrix(0.8796 0.4758 -0.4758 0.8796 601.5169 743.0641)",
				"content": [
					{"text": "Greenwich Village", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "Quality And", "x": 9, "y": 18, "class":"st27 st26"},
					{"text": "Craftsmanship 101", "x": -16.7, "y": 34, "class":"st27 st26"}
				]
			},
			{
				"region": "gramercy",
				"transform": "matrix(0.8898 0.4564 -0.4564 0.8898 739.1454 656.7009)",
				"content": [
					{"text": "Gramercy", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "Romancing", "x": -15.8, "y": 18, "class":"st27 st26"},
					{"text": "Product", "x": -3.7, "y": 34, "class":"st27 st26"}
				]
			},
			{
				"region": "eastvillage",
				"transform": "matrix(0.4211 -0.907 0.907 0.4211 752.6664 872.3807)",
				"content": [
					{"text": "East Village", "x": 0, "y": 0, "class": "st25 st32"},
					{"text": "Price Sandwich", "x": -21.4, "y": 14.6, "class":"st27 st32"},
					{"text": "Technique", "x": -4.2, "y": 27.5, "class":"st27 st32"}
				]
			},
			{
				"region": "upperwestsideneighborhood",
				"transform": "matrix(0.4706 -0.8823 0.8823 0.4706 712.5534 119.5164)",
				"content": [
					{"text": "Upper West Side", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "Personalizing", "x": -2.7, "y": 18, "class":"st27 st26"},
					{"text": "the Experience", "x": -4.6, "y": 34, "class":"st27 st26"}
				]
			},   
			{
				"region": "centralpark",
				"transform": "matrix(0.4744 -0.8803 0.8803 0.4744 828.4642 138.2979)",
				"content": [
					{"text": "Central Park", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "Getting to Know", "x": -28.5, "y": 18, "class":"st27 st26"},
					{"text": "the Customer", "x": -15.9, "y": 34, "class":"st27 st26"}
				]
			},   
			{
				"region": "uppereastside",
				"transform": "matrix(0.4696 -0.8829 0.8829 0.4696 903.2277 189.8457)",
				"content": [
					{"text": "Upper East Side", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "Proposing and", "x": -9.2, "y": 18, "class":"st27 st26"},
					{"text": "Presenting Products", "x": -33.3, "y": 34, "class":"st27 st26"}
				]
			},   
			{
				"region": "yorkville",
				"transform": "matrix(0.4765 -0.8792 0.8792 0.4765 1023.8438 184.0225)",
				"content": [
					{"text": "Yorkville", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "Handling Objections", "x": -55.2, "y": 18, "class":"st27 st26"},
					{"text": "and Closing the Sale", "x": -54.2, "y": 34, "class":"st27 st26"}
				]
			},  
			{
				"region": "tribeca",
				"transform": "matrix(0.8824 0.4706 -0.4706 0.8824 477.6523 932.2043)",
				"content": [
					{"text": "Tribeca", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "Know Your", "x": -20, "y": 18, "class":"st27 st26"},
					{"text": "Competitors", "x": -26.9, "y": 34, "class":"st27 st26"}
				]
			},   
			{
				"region": "financialdistrict",
				"transform": "matrix(0.8964 0.4432 -0.4432 0.8964 398.7719 1034.9568)",
				"content": [
					{"text": "Financial District", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "Retail Math", "x": 5.4, "y": 18, "class":"st27 st26"}
				]
			},  
			{
				"region": "lowereastside",
				"transform": "matrix(0.9294 0.369 -0.369 0.9294 671.2167 947.5052)",
				"content": [
					{"text": "Lower East Side", "x": 0, "y": 0, "class": "st25 st26"},
					{"text": "Operations", "x": 4.5, "y": 18, "class":"st27 st26"}
				]
			},   
			{
				"region": "chinatown",
				"transform": "matrix(0.3946 -0.9189 0.9189 0.3946 575.6385 1035.7544)",
				"content": [
					{"text": "Chinatown", "x": 0, "y": 0, "class": "st25 st33"},
					{"text": "Visual", "x": 7.7, "y": 15.3, "class":"st27 st33"},
					{"text": "Merchan-", "x": -3.9, "y": 28.9, "class":"st27 st33"},
					{"text": "dising", "x": 8.3, "y": 42.6, "class":"st27 st33"}
				]
			}
		],
		selectedColors: this.originalColors,
		getRegionBorderColors: function(selectedArea) {
			var originalColors = this.originalColors;
			var darkColors = this.darkColors;
			var newColors = $.extend( {}, globalDataInteractionObj.mlApprenticeHandler.selectedColors);
			//console.log(selectedArea);
			switch( selectedArea ) {
				case "lowermanhattan":
					newColors['st24l1'] = originalColors['st24l1'];
					newColors['st24l2'] = darkColors['st24l2'];
					newColors['st24l3'] = darkColors['st24l3'];
					newColors['st24l4'] = darkColors['st24l4'];
					newColors['st24l5'] = darkColors['st24l5'];
					newColors['st24l6'] = darkColors['st24l6'];
					newColors['st24l7'] = darkColors['st24l7'];
					break;
				case "thehighline":
					newColors['st24l1'] = darkColors['st24l1'];
					newColors['st24l2'] = originalColors['st24l2'];
					newColors['st24l3'] = originalColors['st24l3'];
					newColors['st24l4'] = darkColors['st24l4'];
					newColors['st24l5'] = originalColors['st24l5'];
					newColors['st24l6'] = darkColors['st24l6'];
					newColors['st24l7'] = darkColors['st24l7'];
					break;
				case "downtown":
					newColors['st24l1'] = originalColors['st24l1'];
					newColors['st24l2'] = originalColors['st24l2'];
					newColors['st24l3'] = originalColors['st24l3'];
					newColors['st24l4'] = originalColors['st24l4'];
					newColors['st24l5'] = darkColors['st24l5'];
					newColors['st24l6'] = darkColors['st24l6'];
					newColors['st24l7'] = darkColors['st24l7'];
					break;
				case "midtownsouth":
					newColors['st24l1'] = darkColors['st24l1'];
					newColors['st24l2'] = darkColors['st24l2'];
					newColors['st24l3'] = originalColors['st24l3'];
					newColors['st24l4'] = originalColors['st24l4'];
					newColors['st24l5'] = originalColors['st24l5'];
					newColors['st24l6'] = originalColors['st24l6'];
					newColors['st24l7'] = darkColors['st24l7'];						
					break;	
				case "midtown":
					newColors['st24l1'] = darkColors['st24l1'];
					newColors['st24l2'] = darkColors['st24l2'];
					newColors['st24l3'] = darkColors['st24l3'];
					newColors['st24l4'] = darkColors['st24l4'];
					newColors['st24l5'] = darkColors['st24l5'];
					newColors['st24l6'] = originalColors['st24l6'];
					newColors['st24l7'] = originalColors['st24l7'];						
					break;			
				case "uptown":
					newColors['st24l1'] = darkColors['st24l1'];
					newColors['st24l2'] = darkColors['st24l2'];
					newColors['st24l3'] = darkColors['st24l3'];
					newColors['st24l4'] = darkColors['st24l4'];
					newColors['st24l5'] = darkColors['st24l5'];
					newColors['st24l6'] = darkColors['st24l6'];
					newColors['st24l7'] = originalColors['st24l7'];						
					break;	
			}		
			return newColors;	
		}
	},
	mlAmbssadorHandler: {
		mapInfo: mlambassador,
		elanMapObjectId: journeys.mlambassador.elan_map_object_id,
		elanMapUnlockObjectId: journeys.mlambassador.first_unlock_object_id,
		originalColors: {},
		darkColors: {},
		pins: {},
		additionalContent: [],
		selectedColors: this.originalColors,
		getRegionBorderColors: function(selectedArea) {
			var originalColors = this.originalColors;
			var darkColors = this.darkColors;
			var newColors = $.extend( {}, globalDataInteractionObj.mlAmbssadorHandler.selectedColors);
			switch( selectedArea ) {
				case 'areaname':
					break;
			}
			return newColors;
		}
	},
    //initialization sequence for the whole object. Call this method on a window onload or a domready event
    init: function()  {
		this.userData.displayMeterCompletions();
        this.utilities.getCurrentMonth();
        this.userData.userInit();
        this.courseData.courseInit();		
        //not very clean, but we're going to give the app 250ms (for now) to get the course data. After that is loaded,
        setTimeout(function()  {
			globalDataInteractionObj.mapInteractionHandler.mapInit();
			globalDataInteractionObj.interactionHandler.subInit();			
		},250);
    },
    //this should be used to grab user and course data on asynchronous view load events
    update: function()  {
        this.userData.userInit();
        this.courseData.courseInit();
    }
};
//Change link colors on explore modal and swap checkbox image based on clicks
$(document).ready(function(){
	// $('.objective-link').click(function(){
	// 	pos = $(this).attr("id");
	// 	console.log(pos);
	// });	
	g2 = new JustGage({
        id: 'g2',
        min: 0,
        max: 22,
        relativeGaugeSize: true,
        gaugeColor: '#50B586',
        hideMinMax: true,
        pointer: true,
        hideValue: true,
        pointerOptions: {
          toplength: -30,
          bottomlength: 50,
          bottomwidth: 6,
          color: '#50B586',
          stroke_linecap: 'round'
        },
        customSectors: [{
          color: '#C6F1DD',
          lo: 0,
          hi: 4
        }, {
          color: '#99E0BF',
          lo: 4,
          hi: 12
        }
        , {
          color: '#77CFA6',
          lo: 12,
          hi: 16
        }
        , {
          color: '#50B586',
          lo: 16,
          hi: 22
        }],
        gaugeWidthScale: 0.8,
        counter: false
      });
});

$(function(){
	globalDataInteractionObj.init();
	
    // Added By Dave

    var AlternateUI = (function(){

        // Clear Hashes On Load
        window.location.hash = '';

        var body = $('body');
        var userMenu = $('#off-canvas-menu');
        var menuDimmer = $('#menu-dimmer');
        var menuTransition = new TimelineLite();
        var menuClosed = true;


        (function pageRoutes(){
            var navLinks = $('a.coach-nav-link');
            var pageTransition = new TimelineLite();
            var allSections = $('.full-page-section');
            var preloader = $('#preloader');

            // Place non active page sections off canvas on load
            TweenLite.to( allSections.not('.activestate'), .01, {x: 700} );
            allSections.not('.activestate').hide();

            navLinks.on('click touchstart', function(e){
                e.preventDefault();

                var $this = $(this).parent('li');
                
                //var destinationPath = this.pathname.replace('/', '');             
                var destinationPath = this.pathname.split('/').slice(-1)[0];
                var destination = $('#' + destinationPath);
                
                if ($this.hasClass('activestate')){                 
                    if( destinationPath == "mapJourney") {
                        globalDataInteractionObj.mapInteractionHandler.resetMap();
                    }                   
                    return;
                }

                // Remove Monthly Focus Page Modal If Open Before Page Transition
                $('.fade-in-trigger').removeClass('fade-in-trigger');
                var currentPage = $('.full-page-section.activestate');

                pageTransition
                    .to(currentPage, .65, {x: -700, autoAlpha: 0, ease: 'Expo.easeIn'})
                    .to(currentPage, .01, {x: 700, onComplete: function(){
                            currentPage.hide();
                            body.attr('data-page', destinationPath);
                            $(window).scrollTop(0);
                            navLinks.parents('li').add(allSections).removeClass('activestate');
                            $this.add(destination).addClass('activestate');
                            destination.show(1, function(){
                                if (destination.attr('id') == "mapJourney") {
                                    $this.css('pointer-events', 'auto');
                                    $(window).trigger('resize');                                    
                                } 
                            });
                            
                        }
                    })
                    .to(destination, .65, {x: 0, autoAlpha: 1, ease: 'Expo.easeOut', onComplete: function(){
                            if (destination.attr('id') == "mapJourney") {
                                globalDataInteractionObj.mapInteractionHandler.resetMap();
                                $(window).trigger('resize');
                            }
                        }
                    });             
            });
        })();

        
        function toggleMenu(state, timing){
            if (state == 'open') {
                menuTransition
                    .to(menuDimmer, .1, {autoAlpha: 1, ease: 'Power3.easeIn'})
                    .to(userMenu, timing, {x: 0, ease: 'Expo.easeOut'});
                    menuClosed = false;
                    body.addClass('no-scroll');
            }

            else {
                menuTransition
                    .to(menuDimmer, .1, {autoAlpha: 0, ease: 'Power3.easeIn'})
                    .to(userMenu, timing, {x: 410, ease: 'Expo.easeOut'});
                    menuClosed = true;
                    body.removeClass('no-scroll');
            }
        }

        
        (function slideMenu(){

            $('#menu-burger').on('click', function(){
                if (menuClosed){
                    toggleMenu('open', .65);
                }

                else {
                    toggleMenu('close', .65);
                }
            });

            menuDimmer.add('#off-canvas-menu .icon-menu-cross').on('click touchstart', function(){
                toggleMenu('close', .4);
            });

            $(window).on('resize.userMenu', function(){
                if (!menuClosed) {
                    toggleMenu('close', .01);
                }
            });

        })();


        (function videoPlayer(){

            $('body').on('click touchstart', '.play-video', function(e){
                if(!$(this).hasClass('disabled')) {
                    e.preventDefault();
                    var record_id = $(this).attr('attr-record-id');
                    var parent_object_id = $(this).attr('attr-parent');
                    var object_id = $(this).attr('id');
                    var step_num = 1;
                    $('div.pre-load-modal').fadeIn(300);
                    globalDataInteractionObj.ajaxUtilities.ajaxLauncher('getcoursevideo', record_id, parent_object_id, object_id, step_num);
                }
            });
        })();

        (function pdfModal(){
            
            
            //open pdf in modal window
            $('body').on('click touchstart', 'ul li a.Link', function(e){
              e.preventDefault();
              var modal = $('#pdf-modal');
              var preloader = $('#pdf-preloader');
              var theSrc;
              var parent_id = $(this).attr('attr-parent');

              var object_id = $(this).attr('id');
              if(!$(this).hasClass('disabled')) {
                  // Replace this with BIW function
                  var theHref = this.href;
                  // ---------------------

                  theSrc = (window.innerWidth < 1025) ? 'https://drive.google.com/viewerng/viewer?embedded=true&url=' + theHref : theHref;

                  modal.find('iframe').attr('src', theSrc);
                  preloader.show();
                  modal.fadeIn(300);
                  globalDataInteractionObj.ajaxUtilities.ajaxLauncher('updatecreateuserrecord', object_id, parent_id,'Complete');
                  monthly_focus.child = true;
              }

              modal.add('close-button').on('click touchstart', function(){
                   modal.fadeOut(300, function(){
                      monthly_focus.child = false;
                      modal.find('iframe').attr('src', '');                   
                  });
                });

              $('iframe').on('load', function(){
                  preloader.fadeOut(100);
                });
           });
        

            //open and fill quiz in modal window
            $('body').on('click touchstart', 'ul li a.Quiz', function(e){
                // console.log("quiz clicked");
                e.preventDefault();
                if(!$(this).hasClass('disabled')) {
                    $('div.pre-load-modal').fadeIn(300);
                    var modal = $('div.quiz-container');
                    modal.width($('.test-size').width());
                    var parent_id = $(this).attr('attr-parent');
                    var object_id = $(this).attr('id');
                    var count = 1;
                    var answers = [];
                    var pass_percent = $(this).attr('attr-quiz-percent');
    				//console.log('pass_percent: ' + pass_percent);				
    				//console.log(answers);
                    monthly_focus.child = true;
    				
                    var record_id = $("#quiz_record_id").val();
                
                    // console.log("Modal-"+modal);
                    globalDataInteractionObj.ajaxUtilities.fillQuizQuestions(object_id, parent_id);
                    modal.fadeIn(500);
                }
               $('body').on('click touchstart', '.quiz-container .icon-close-btn', function(){				   
                   modal.fadeOut(300, function(){
                      $('div.quiz-container').html('');
                      monthly_focus.child = false;
                   });
                });

               $('body').on('click touchstart', '.quiz-container .next', function(e){
                    e.preventDefault;
                    //Hide all of the error messages
                    $('.quiz-container .errormsg').hide();

                    //check to see if they selected an answer
                    if($("input[name='"+count+"']").is(':checked')) {
                        answers.push($("input[name='"+count+"']:checked").val());
                        //Check to see if this was the last question
                        if(count < quiz.data.DATA.length) {
                           $('.quiz-container .question'+count).hide();
                           count ++;
                           $('.quiz-container .question'+count).show();
                        } else {
                            quiz.answers = answers;
							answers = [];
							//console.log('pass_percent: ' + pass_percent);
                            gradeQuiz(pass_percent, object_id, parent_id);                            
                        }
                    } else {
                        $('.quiz-container .errormsg').show();
                    }
					
					//console.log(answers);
                });


               
            });
            
          })();

          function gradeQuiz(pass_percent, object_id, parent_id) {
            var correct = 0;
            var question_count = 1;
            var record_id = $("#quiz_record_id").val();
            var pass = "Failed";
			//console.log(quiz.answers);	
            quiz.answers.forEach(function(answer) {
				//console.log(answer);
                if(quiz.data.DATA[question_count - 1]['ANSWERS'][answer -1]['CORRECT'] == 1) {
                    correct++;
                }
                question_count++;

                globalDataInteractionObj.ajaxUtilities.ajaxLauncher('submitquizanswers', record_id, answer, question_count-1);
            });
            question_count--;
			
			var user_percent = (correct / question_count) * 100;
			
			//console.log('correct: ' + correct);
			//console.log('question_count: ' + question_count);
			//console.log('pass_percent: ' + pass_percent);			
			//console.log('user_percent: ' + user_percent);
			
            if ( user_percent >= pass_percent) {
                pass = "Passed";
                $('.quiz-container .quiz-results').html("Congratulations!<p>You passed the assessment.");
                $('#svg-'+parent_id).html(user_percent+'%');
                $('.svg-'+parent_id).show();

                globalDataInteractionObj.ajaxUtilities.removeDisableClassForNextChild(object_id, parent_id);
                var passed = 0;
                for(var row_key in globalDataInteractionObj.objectProperties.rawAjaxCourseData){
                    for(var object_key in globalDataInteractionObj.objectProperties.rawAjaxCourseData[row_key]) {
                        if(globalDataInteractionObj.objectProperties.rawAjaxCourseData[row_key][object_key]['course_id'] == parent_id){
                            globalDataInteractionObj.objectProperties.rawAjaxCourseData[row_key][object_key]['course_percent'] = user_percent+'%';
                        }
                        if(globalDataInteractionObj.objectProperties.rawAjaxCourseData[row_key][object_key]['course_percent'] != '') {
                            passed ++;
                        }
                    }
                }
                globalDataInteractionObj.objectProperties.rawAjaxCourseData['passed_assessments'] = passed;
                var percent_done = Math.round(passed/globalDataInteractionObj.objectProperties.rawAjaxCourseData['total_assessments']*100);
                $('.data-course-completion').text(percent_done+'%');

            } else {
                $('.quiz-container .quiz-results').html("You did not pass the assessment. The minimum passing score is "+pass_percent+"%. Please review the information in this focus again and retake the assessment.");
            }
            $('.quiz-container .question').hide();
            $('.quiz-container .quiz-results').show();

			//console.log(record_id + ' - ' + pass);
            globalDataInteractionObj.ajaxUtilities.ajaxLauncher('updateuserobjectrecord', record_id, pass, user_percent);
            //console.log(correct+ " Correct out of "+question_count);
          }

        (function mapLegend(){

            $(document).on('click.region touchstart.region', '.jqvmap-region', function(e){

                $('.map-legend ul li').removeClass('active');

                switch(e.target.id){

                    case 'jqvmap1_financialdistrict':
                    case 'jqvmap1_chinatown':
                    case 'jqvmap1_tribeca':
                    case 'jqvmap1_lowereastside':
                       $('.lower').addClass('active');
                        break;

                    case 'jqvmap1_eastvillage':
                    case 'jqvmap1_greenwichvillage':
                    case 'jqvmap1_soho':
                    case 'jqvmap1_westvillage':
                    case 'jqvmap1_chelsea':
                    case 'jqvmap1_gramercy':
                        $('.downtown').addClass('active');
                        break;

                    case 'jqvmap1_thehighlineneighborhood':
                        $('.highline').addClass('active');
                        break;

                    case 'jqvmap1_murrayhill':
                    case 'jqvmap1_garmentdistrict':
                    case 'jqvmap1_hellskitchen':
                        $('.midtown-south').addClass('active');
                        break;

                    case 'jqvmap1_clinton':
                    case 'jqvmap1_columbuscircle':
                    case 'jqvmap1_midtowneast':
                    case 'jqvmap1_theaterdistrict':
                        $('.midtown').addClass('active');
                        break;

                    case 'jqvmap1_upperwestsideneighborhood':
                    case 'jqvmap1_centralpark':
                    case 'jqvmap1_uppereastside':
                    case 'jqvmap1_yorkville':
                        $('.upper').addClass('active');
                        break;
                }

            });

        })();


    })();


});

function testcheck()
{
    if (!jQuery("#terms").is(":checked")) {
        document.getElementById('nameError').style.display = "block";
        return false;
    }
    return true;
}
